#!/usr/bin/python3
#coding=utf-8

import sys
import datetime
sys.path.insert(0, '../')
sys.dont_write_bytecode = True

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from tensorboardX import SummaryWriter
import dataset
from net.net_psp  import PSPSkdNet
from apex import amp
from core.criterion import CrossEntropy, KLDivLoss, SALoss, SFLoss
import os
import numpy as np
os.environ["CUDA_VISIBLE_DEVICES"] = "1"


# model_version='resnet18', pretrain='/data/PreModels/resnet18-5c106cde.pth',
# model_version = 'resnet34', pretrain = '/data/PreModels/resnet34-333f7ec4.pth',
# model_version='resnet50', pretrain='/data/PreModels/resnet50-19c8e357.pth',
def train(Dataset, Network):
    ## dataset
    # cfg    = Dataset.Config(datapath='/data/ExpData/Train/CAMP/', savepath='./out', model_version='resnet50', pretrain='/data/PreModels/resnet50-19c8e357.pth',
    #                         mode='train', batch=10, lr=0.05, momen=0.9, decay=5e-4, epoch=20)
    # cfg = Dataset.Config(datapath='/data/ExpData/Train/COD/', savepath='./out', model_version='resnet18', pretrain='/data/PreModels/resnet18-5c106cde.pth',
    #                      mode='train', batch=10, lr=0.05, momen=0.9, decay=5e-4, epoch=20)
    cfg = Dataset.Config(datapath='/data/ExpData/Train/DUT-OMROM/', savepath='./out', model_version='resnet50', pretrain='/data/PreModels/resnet50-19c8e357.pth',
                         mode='train', batch=10, lr=0.05, momen=0.9, decay=5e-4, epoch=20)
    # cfg = Dataset.Config(datapath='/data/ExpData/Train/SOC/', savepath='./out', model_version='resnet50', pretrain='/data/PreModels/resnet50-19c8e357.pth',
    #                      mode='train', batch=10, lr=0.05, momen=0.9, decay=5e-4, epoch=20)
    # cfg = Dataset.Config(datapath='/data/ExpData/Train/DUTS/', savepath='./out/', model_version='resnet50', pretrain='/data/PreModels/resnet50-19c8e357.pth',
    #                      mode='train', batch=10, lr=0.05, momen=0.9, decay=5e-4, epoch=20)
    # cfg = Dataset.Config(datapath='/data/ExpData/Train/THUR/', savepath='./out/',  model_version = 'resnet34', pretrain = '/data/PreModels/resnet34-333f7ec4.pth',
    #                      mode='train', batch=10, lr=0.05, momen=0.9, decay=5e-4, epoch=20)
    data   = Dataset.Data(cfg)
    loader = DataLoader(data, collate_fn=data.collate, batch_size=cfg.batch, shuffle=True)
    ## network
    net    = Network(cfg)
    net.train(True)
    # gpus = list([0,])
    # net = torch.nn.DataParallel(net, device_ids=gpus)
    if torch.cuda.is_available():
        net.cuda()

    # parameter
    base, head = [], []
    for name, param in net.named_parameters():
        if 'bkbone.conv1' in name or 'bkbone.bn1' in name:
            print(name)
        elif 'bkbone' in name:
            base.append(param)
        else:
            head.append(param)
    optimizer      = torch.optim.SGD([{'params':base}, {'params':head}], lr=cfg.lr, momentum=cfg.momen, weight_decay=cfg.decay, nesterov=True)
    net, optimizer = amp.initialize(net, optimizer, opt_level='O2')

    global_step    = 0
    CE = CrossEntropy()
    AKD = SALoss()
    KLD = KLDivLoss(T1=1, T2=1)
    ASKD = SFLoss()

    for epoch in range(cfg.epoch):
        optimizer.param_groups[0]['lr'] = (1-abs((epoch+1)/(cfg.epoch+1)*2-1))*cfg.lr*0.1
        optimizer.param_groups[1]['lr'] = (1-abs((epoch+1)/(cfg.epoch+1)*2-1))*cfg.lr
        num = 1

        for step, (image, mask) in enumerate(loader):
            image, mask = image.cuda().float(), mask.cuda().float()
            pred, scorepsp, featpsp, bkfeat = net(image)
            pred = F.interpolate(pred, size=mask.size()[2:], mode='bilinear')
            loss0 = CE(pred, mask)


            for j, score in enumerate(scorepsp):
                score = F.interpolate(scorepsp[j], size=mask.size()[2:], mode='bilinear')
                scorepsp[j] = score
                feat = F.interpolate(featpsp[j], size=mask.size()[2:], mode='bilinear')
                featpsp[j] = feat
                bfeat = F.interpolate(bkfeat[j], size=mask.size()[2:], mode='bilinear')
                bkfeat[j] = bfeat

            ce_loss1 = []
            kl_loss1 = []
            akl_loss1 = []
            bkl_loss1 = []

            featscore = scorepsp[0:4]
            kd_pspfeat = featpsp[0:4]
            kd_bkfeat = bkfeat[0:4]
            for j, output in enumerate(featscore):
                ce_loss1.append(CE(output, mask))
                tfeat = kd_pspfeat[j]
                t_bfeat = kd_bkfeat[j]
                for k, output_counterpart in enumerate(featscore):
                    if output_counterpart is not output:
                        kl_loss1.append(KLD(output.detach(), output_counterpart))
                        sfeat = kd_pspfeat[k]
                        akl_loss1.append(ASKD(tfeat.detach(), sfeat))
                        s_bfeat = kd_bkfeat[k]
                        bkl_loss1.append(ASKD(t_bfeat.detach(), s_bfeat))
                    else:
                        pass
            loss_cst_ce = sum(ce_loss1) / len(ce_loss1)
            loss_cst_kd = sum(kl_loss1) / len(kl_loss1)
            loss_cst_akd = sum(akl_loss1) / len(akl_loss1)
            loss_cst_bkd = sum(bkl_loss1) / len(bkl_loss1)
            loss_cst = loss_cst_ce + loss_cst_kd + loss_cst_akd + loss_cst_bkd

            ce_loss2 = []
            kl_loss2 = []
            akl_loss2 = []
            bkl_loss2 = []
            featscore = scorepsp[0:4]
            kd_pspfeat = featpsp[0:4]
            kd_bkfeat = bkfeat[0:4]
            output = scorepsp[-1]
            t_pspfeat = featpsp[-1]
            t_bkfeat = bkfeat[-1]
            ce_loss2.append(CE(output, mask))
            for j, output_counterpart in enumerate(featscore):
                if output_counterpart is not output:
                    kl_loss2.append(KLD(output.detach(), output_counterpart))
                    s_pspfeat = kd_pspfeat[j]
                    akl_loss2.append(ASKD(t_pspfeat.detach(), s_pspfeat))
                    s_bkfeat = kd_bkfeat[j]
                    bkl_loss2.append(ASKD(t_bkfeat.detach(), s_bkfeat))

                else:
                    pass

            loss_b2u_ce = sum(ce_loss2) / len(ce_loss2)
            loss_b2u_kd = sum(kl_loss2) / len(kl_loss2)
            loss_b2u_akd = sum(akl_loss2) / len(akl_loss2)
            loss_b2u_bkd = sum(bkl_loss2) / len(bkl_loss2)
            loss_b2u = loss_b2u_ce + loss_b2u_kd + loss_b2u_akd + loss_b2u_bkd

            loss = loss0 + loss_cst + loss_b2u




            optimizer.zero_grad()
            with amp.scale_loss(loss, optimizer) as scale_loss:
                scale_loss.backward()



            optimizer.step()

            if step%10 == 0:                
                print('%s | step:%d/%d/%d | lr=%.6f | loss=%.6f| loss_CE=%.6f| | loss_cst=%.6f| loss_b2u=%.6f' % (datetime.datetime.now(), global_step, epoch + 1, cfg.epoch, optimizer.param_groups[0]['lr'], loss.item(), loss0.item(), loss_cst.item(), loss_b2u.item()))

        if (epoch + 1) == 20:
          torch.save(net.state_dict(), cfg.savepath + '/psp_model-' + str(epoch + 1))


if __name__=='__main__':
    train(dataset, PSPSkdNet)
