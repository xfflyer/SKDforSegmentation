#!/usr/bin/python3
#coding=utf-8

import sys
import datetime
sys.path.insert(0, '../')
sys.dont_write_bytecode = True

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from tensorboardX import SummaryWriter
import dataset
from net.net_tf  import TFKDNet
from apex import amp
from core.criterion import CrossEntropy

import os
import numpy as np
import matplotlib.pyplot as plt

os.environ["CUDA_VISIBLE_DEVICES"] = "0"

def loss_kd_regularization(outputs, labels, ce, reg_alpha, reg_temperature, multiplier):
    """
    loss function for mannually-designed regularization: Tf-KD_{reg}
    """
    alpha = reg_alpha
    T = reg_temperature
    correct_prob = 0.99    # the probability for correct class in u(k)
    loss_CE = ce(outputs, labels)

    K = outputs.size(1)
    N, C, W, H = outputs.shape

    teacher_soft = torch.ones_like(outputs).cuda().float()
    teacher_soft = teacher_soft*(1-correct_prob)/(K-1)  # p^d(k)
    teacher_soft_1 = teacher_soft[:,0,:,:]
    teacher_soft_2 = teacher_soft[:,1,:,:]

    for i in range(outputs.shape[0]):
        teacher_soft_1_buff = teacher_soft_1[i, :, :]
        teacher_soft_2_buff = teacher_soft_2[i, :, :]
        labelbuff = labels[i, 0, :, :]
        teacher_soft_2_buff[labelbuff==1] = torch.tensor(correct_prob).cuda().float()
        teacher_soft_1_buff = 1-teacher_soft_2_buff
        teacher_soft_1[i, :, :] = teacher_soft_1_buff
        teacher_soft_2[i, :, :] = teacher_soft_2_buff
    teacher_soft[:, 0, :, :] = teacher_soft_1
    teacher_soft[:, 1, :, :] = teacher_soft_2
    N, C, W, H = outputs.shape
    p = F.softmax(outputs.permute(0, 2, 3, 1).contiguous().view(-1, C), dim=1)
    q = teacher_soft.permute(0, 2, 3, 1).contiguous().view(-1, C)
    b, c = p.size()
    epsilon = 1e-8
    _p = (p + epsilon * torch.ones(b, c).cuda()) / (1.0 + c * epsilon)
    _q = (q + epsilon * torch.ones(b, c).cuda()) / (1.0 + c * epsilon)
    loss_soft_regu = (1 ** 2) * torch.mean(torch.sum(_p * torch.log(_p / _q), dim=1))
    KD_loss =  loss_CE + loss_soft_regu

    return KD_loss


def feature_loss_function(fea, target_fea):
    loss = (fea - target_fea)**2 * ((fea > 0) | (target_fea > 0)).float()
    return torch.abs(loss).mean()

# model_version='resnet18', pretrain='/data/PreModels/resnet18-5c106cde.pth',
# model_version='resnet18', pretrain='/data/PreModels/resnet18-5c106cde.pth',
def train(Dataset, Network):
    ## dataset
    # cfg    = Dataset.Config(datapath='/data/Datasets/CamouflageDataset/', savepath='./out', model_version='resnet18', pretrain='/data/PreModels/resnet18-5c106cde.pth',
    #                         mode='train', batch=10, lr=0.05, momen=0.9, decay=5e-4, epoch=20)
    # cfg = Dataset.Config(datapath='/data/Datasets/CamOD/HRN/', savepath='./out', model_version = 'resnet34', pretrain = '/data/PreModels/resnet34-333f7ec4.pth',
    #                      mode='train', batch=10, lr=0.05, momen=0.9, decay=5e-4, epoch=20)
    # cfg = Dataset.Config(datapath='/data/Datasets/DUT-OMROM/', savepath='./out', model_version='resnet18', pretrain='/data/PreModels/resnet18-5c106cde.pth',
    #                      mode='train', batch=10, lr=0.05, momen=0.9, decay=5e-4, epoch=20)
    # cfg = Dataset.Config(datapath='/data/ExpData/Train/DUTS/', savepath='./out', model_version='resnet50', pretrain='/data/PreModels/resnet50-19c8e357.pth',
    #                      mode='train', batch=10, lr=0.05, momen=0.9, decay=5e-4, epoch=20)
    # cfg = Dataset.Config(datapath='/data/ExpData/Train/SOC/', savepath='./out/', model_version='resnet18', pretrain='/data/PreModels/resnet18-5c106cde.pth',
    #                      mode='train', batch=10, lr=0.05, momen=0.9, decay=5e-4, epoch=20)
    cfg = Dataset.Config(datapath='/data/ExpData/Train/THUR/', savepath='./out/',  model_version='resnet50', pretrain='/data/PreModels/resnet50-19c8e357.pth',
                         mode='train', batch=10, lr=0.05, momen=0.9, decay=5e-4, epoch=20)
    data   = Dataset.Data(cfg)
    loader = DataLoader(data, collate_fn=data.collate, batch_size=cfg.batch, shuffle=True)
    ## network
    net    = Network(cfg)
    net.train(True)
    if torch.cuda.is_available():
        net.cuda()

    ## parameter
    base, head = [], []
    for name, param in net.named_parameters():
        if 'bkbone.conv1' in name or 'bkbone.bn1' in name:
            print(name)
        elif 'bkbone' in name:
            base.append(param)
        else:
            head.append(param)
    optimizer      = torch.optim.SGD([{'params':base}, {'params':head}], lr=cfg.lr, momentum=cfg.momen, weight_decay=cfg.decay, nesterov=True)
    net, optimizer = amp.initialize(net, optimizer, opt_level='O2')
    sw             = SummaryWriter(cfg.savepath)
    global_step    = 0
    CE = CrossEntropy()
    for epoch in range(cfg.epoch):
        optimizer.param_groups[0]['lr'] = (1-abs((epoch+1)/(cfg.epoch+1)*2-1))*cfg.lr*0.1
        optimizer.param_groups[1]['lr'] = (1-abs((epoch+1)/(cfg.epoch+1)*2-1))*cfg.lr
        num = 1
        for step, (image, mask) in enumerate(loader):
            image, mask = image.cuda().float(), mask.cuda().float()
            pred = net(image)
            pred = F.interpolate(pred, size=mask.size()[2:], mode='bilinear')
            loss0 = loss_kd_regularization(pred, mask, CE, 0.1, 1, 1)

            loss = loss0


            optimizer.zero_grad()
            with amp.scale_loss(loss, optimizer) as scale_loss:
                scale_loss.backward()

            optimizer.step()

            if step%10 == 0:
                print('%s | step:%d/%d/%d | lr=%.6f | loss=%.6f'%(datetime.datetime.now(), global_step, epoch+1, cfg.epoch, optimizer.param_groups[0]['lr'], loss.item()))

        if (epoch + 1)  == 20:
            torch.save(net.state_dict(), cfg.savepath + '/tf_model1-' + str(epoch + 1))

if __name__=='__main__':
    train(dataset, TFKDNet)
