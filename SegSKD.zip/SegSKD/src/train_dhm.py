#!/usr/bin/python3
#coding=utf-8

import sys
import datetime
sys.path.insert(0, '../')
sys.dont_write_bytecode = True

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from tensorboardX import SummaryWriter
import dataset
from net.net_dhm  import DHMSegNet
from apex import amp
from core.criterion import CrossEntropy, KLDivLoss
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

# model_version='resnet50', pretrain='/data/PreModels/resnet50-19c8e357.pth',
# model_version = 'resnet34', pretrain = '/data/PreModels/resnet34-333f7ec4.pth',
# model_version='resnet18', pretrain='/data/PreModels/resnet18-5c106cde.pth',
def train(Dataset, Network):
    ## dataset
    # cfg    = Dataset.Config(datapath='/data/Datasets/CamouflageDataset/', savepath='./out', model_version = 'resnet34', pretrain = '/data/PreModels/resnet34-333f7ec4.pth',
    #                         mode='train', batch=10, lr=0.05, momen=0.9, decay=5e-4, epoch=20)
    # cfg = Dataset.Config(datapath='/data/Datasets/CamOD/HRN/', savepath='./out', model_version='resnet34', pretrain='/data/PreModels/resnet34-333f7ec4.pth',
    #                      mode='train', batch=10, lr=0.05, momen=0.9, decay=5e-4, epoch=20)
    # cfg = Dataset.Config(datapath='/data/Datasets/DUT-OMROM/', savepath='./out', model_version='resnet34', pretrain='/data/PreModels/resnet34-333f7ec4.pth',
    #                      mode='train', batch=10, lr=0.05, momen=0.9, decay=5e-4, epoch=20)
    # cfg = Dataset.Config(datapath='/data/ExpData/Train/DUTS/', savepath='./out', model_version='resnet34', pretrain='/data/PreModels/resnet34-333f7ec4.pth',
    #                      mode='train', batch=10, lr=0.05, momen=0.9, decay=5e-4, epoch=20)
    cfg = Dataset.Config(datapath='/data/ExpData/Train/SOC/', savepath='./out/', model_version='resnet18', pretrain='/data/PreModels/resnet18-5c106cde.pth',
                         mode='train', batch=10, lr=0.05, momen=0.9, decay=5e-4, epoch=20)

    data   = Dataset.Data(cfg)
    loader = DataLoader(data, collate_fn=data.collate, batch_size=cfg.batch, shuffle=True)
    ## network
    net    = Network(cfg)
    net.train(True)
    if torch.cuda.is_available():
        net.cuda()

    ## parameter
    base, head = [], []
    for name, param in net.named_parameters():
        if 'bkbone.conv1' in name or 'bkbone.bn1' in name:
            print(name)
        elif 'bkbone' in name:
            base.append(param)
        else:
            head.append(param)
    optimizer      = torch.optim.SGD([{'params':base}, {'params':head}], lr=cfg.lr, momentum=cfg.momen, weight_decay=cfg.decay, nesterov=True)
    net, optimizer = amp.initialize(net, optimizer, opt_level='O2')
    sw             = SummaryWriter(cfg.savepath)
    global_step    = 0
    CE = CrossEntropy()
    KD1 = KLDivLoss(T1=1, T2=1)
    for epoch in range(cfg.epoch):
        optimizer.param_groups[0]['lr'] = (1-abs((epoch+1)/(cfg.epoch+1)*2-1))*cfg.lr*0.1
        optimizer.param_groups[1]['lr'] = (1-abs((epoch+1)/(cfg.epoch+1)*2-1))*cfg.lr
        num = 1
        for step, (image, mask) in enumerate(loader):
            image, mask = image.cuda().float(), mask.cuda().float()
            pred, featscore = net(image)
            pred = F.interpolate(pred, size=mask.size()[2:], mode='bilinear')
            loss0 = CE(pred, mask)

            for j, score in enumerate(featscore):
                score = F.interpolate(featscore[j], size=mask.size()[2:], mode='bilinear')
                featscore[j] = score

            ce_loss = []
            kl_loss = []
            for j, output in enumerate(featscore):
                ce_loss.append(CE(output, mask))
                for output_counterpart in featscore:
                    if output_counterpart is not output:

                        kl_loss.append(KD1(output.detach(), output_counterpart))
                    else:
                        pass
            loss1 = (ce_loss + kl_loss)

            loss = loss0 + sum(loss1)/len(loss1)


            optimizer.zero_grad()
            with amp.scale_loss(loss, optimizer) as scale_loss:
                scale_loss.backward()

            optimizer.step()

            if step%10 == 0:
                print('%s | step:%d/%d/%d | lr=%.6f | loss=%.6f'%(datetime.datetime.now(), global_step, epoch+1, cfg.epoch, optimizer.param_groups[0]['lr'], loss.item()))
                # if epoch == 0:
                #     torch.save(net.state_dict(), cfg.savepath + '/model2_epoch1_batch-' + str(num))
                #     num = num+1

        if (epoch + 1) == 20:
            torch.save(net.state_dict(), cfg.savepath + '/dhm_model1-' + str(epoch + 1))

if __name__=='__main__':
    train(dataset, DHMSegNet)
