#!/usr/bin/python3
#coding=utf-8

import sys
import datetime
sys.path.insert(0, '../')
sys.dont_write_bytecode = True

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from tensorboardX import SummaryWriter
import dataset
from net.net_byot  import BYOTSegNet
from apex import amp
from core.criterion import CrossEntropy, KLDivLoss

import os
import numpy as np
import matplotlib.pyplot as plt

os.environ["CUDA_VISIBLE_DEVICES"] = "1"
# model_version='resnet18', pretrain='/data/PreModels/resnet18-5c106cde.pth',
# model_version='resnet50', pretrain='/data/PreModels/resnet50-19c8e357.pth',
# model_version='resnet34', pretrain='/data/PreModels/resnet34-333f7ec4.pth',
def feature_loss_function(fea, target_fea):
    loss = (fea - target_fea)**2 * ((fea > 0) | (target_fea > 0)).float()
    return torch.abs(loss).mean()

def train(Dataset, Network):
    ## dataset
    # cfg    = Dataset.Config(datapath='/data/ExpData/Train/CAMP/', savepath='./out', model_version='resnet34', pretrain='/data/PreModels/resnet34-333f7ec4.pth',
    #                         mode='train', batch=6, lr=0.05, momen=0.9, decay=5e-4, epoch=20)
    # cfg = Dataset.Config(datapath='/data/ExpData/Train/COD/', savepath='./out', mode='train', model_version='resnet18', pretrain='/data/PreModels/resnet18-5c106cde.pth',
    #                      batch=10, lr=0.05, momen=0.9, decay=5e-4, epoch=20)
    cfg = Dataset.Config(datapath='/data/ExpData/Train/DUT-OMROM/', savepath='./out', model_version='resnet18', pretrain='/data/PreModels/resnet18-5c106cde.pth',
                         mode='train', batch=10, lr=0.05, momen=0.9, decay=5e-4, epoch=20)
    # cfg = Dataset.Config(datapath='/data/ExpData/Train/SOC/', savepath='./out', mode='train', model_version='resnet34', pretrain='/data/PreModels/resnet34-333f7ec4.pth',
    #                      batch=10, lr=0.05, momen=0.9, decay=5e-4, epoch=20)
    # cfg = Dataset.Config(datapath='/data/ExpData/Train/DUTS/', savepath='./out', mode='train', model_version='resnet18', pretrain='/data/PreModels/resnet18-5c106cde.pth',
    #                      batch=10, lr=0.05, momen=0.9, decay=5e-4, epoch=20)
    # cfg = Dataset.Config(datapath='/data/ExpData/Train/THUR/', savepath='./out', model_version='resnet50', pretrain='/data/PreModels/resnet50-19c8e357.pth',
    #                      mode='train', batch=10, lr=0.05, momen=0.9, decay=5e-4, epoch=20)


    data   = Dataset.Data(cfg)
    loader = DataLoader(data, collate_fn=data.collate, batch_size=cfg.batch, shuffle=True)
    ## network
    net    = Network(cfg)
    net.train(True)
    # gpus = list([0,])
    # net = torch.nn.DataParallel(net, device_ids=gpus)
    if torch.cuda.is_available():
        net.cuda()

    ## parameter
    base, head = [], []
    for name, param in net.named_parameters():
        if 'bkbone.conv1' in name or 'bkbone.bn1' in name:
            print(name)
        elif 'bkbone' in name:
            base.append(param)
        else:
            head.append(param)
    optimizer      = torch.optim.SGD([{'params':base}, {'params':head}], lr=cfg.lr, momentum=cfg.momen, weight_decay=cfg.decay, nesterov=True)
    net, optimizer = amp.initialize(net, optimizer, opt_level='O2')
    sw             = SummaryWriter(cfg.savepath)
    global_step    = 0
    CE = CrossEntropy()
    KLD = KLDivLoss(T1=1, T2=1)
    for epoch in range(cfg.epoch):
        optimizer.param_groups[0]['lr'] = (1-abs((epoch+1)/(cfg.epoch+1)*2-1))*cfg.lr*0.1
        optimizer.param_groups[1]['lr'] = (1-abs((epoch+1)/(cfg.epoch+1)*2-1))*cfg.lr
        num = 1
        for step, (image, mask) in enumerate(loader):
            image, mask = image.cuda().float(), mask.cuda().float()
            pred, featscore = net(image)
            pred = F.interpolate(pred, size=mask.size()[2:], mode='bilinear')
            loss0 = CE(pred, mask)

            subloss1 = CE(featscore[0], mask)
            subloss2 = CE(featscore[1], mask)
            subloss3 = CE(featscore[2], mask)
            subloss4 = CE(featscore[3], mask)
            subloss5 = CE(featscore[4], mask)
            subloss = (subloss1 + subloss2 + subloss3 + subloss4 + subloss5)/5

            h, w = mask[0].size(-2), mask[0].size(-1)
            outhead_output = featscore[-1]
            outhead_output = F.upsample(input=outhead_output, size=(h, w), mode='bilinear')

            outhead_output = F.softmax(outhead_output, dim=1)

            subhead1_output = featscore[0]
            subhead1_output = F.upsample(input=subhead1_output, size=(h, w), mode='bilinear')
            kdloss1 = KLD(outhead_output.detach(), subhead1_output)
            featloss1 = feature_loss_function(subhead1_output, outhead_output.detach())

            subhead2_output = featscore[1]
            subhead2_output = F.upsample(input=subhead2_output, size=(h, w), mode='bilinear')
            kdloss2 = KLD(outhead_output.detach(), subhead2_output)
            featloss2 = feature_loss_function(subhead2_output, outhead_output.detach())

            subhead3_output = featscore[2]
            subhead3_output = F.upsample(input=subhead3_output, size=(h, w), mode='bilinear')
            kdloss3 = KLD(outhead_output.detach(), subhead3_output)
            featloss3 = feature_loss_function(subhead3_output, outhead_output.detach())

            subhead4_output = featscore[3]
            subhead4_output = F.upsample(input=subhead4_output, size=(h, w), mode='bilinear')
            kdloss4 = KLD(outhead_output.detach(), subhead4_output)
            featloss4 = feature_loss_function(subhead4_output, outhead_output.detach())

            kdloss = (kdloss1 + kdloss2 + kdloss3 + kdloss4)/4

            featloss = (featloss1 + featloss2 + featloss3 + featloss4) / 4

            loss = loss0 + subloss + kdloss + featloss


            optimizer.zero_grad()
            with amp.scale_loss(loss, optimizer) as scale_loss:
                scale_loss.backward()

            optimizer.step()

            if step%10 == 0:
                print('%s | step:%d/%d/%d | lr=%.6f | loss=%.6f'%(datetime.datetime.now(), global_step, epoch+1, cfg.epoch, optimizer.param_groups[0]['lr'], loss.item()))

        if (epoch + 1) == 20:
            torch.save(net.state_dict(), cfg.savepath + '/byot_model1-' + str(epoch + 1))

if __name__=='__main__':
    train(dataset, BYOTSegNet)
