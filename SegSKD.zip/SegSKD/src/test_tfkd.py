#!/usr/bin/python3
#coding=utf-8

import os
import sys
sys.path.insert(0, '../')
sys.dont_write_bytecode = True

import cv2
import numpy as np
import matplotlib.pyplot as plt


import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from tensorboardX import SummaryWriter
import dataset
from net.net_tf  import TFKDNet

os.environ["CUDA_VISIBLE_DEVICES"] = "1"
class Test(object):
    def __init__(self, Dataset, Network, path):
        ## dataset
        self.cfg    = Dataset.Config(datapath=path, model_version='resnet50', snapshot='./out/tf_model1-20', mode='test')
        self.data   = Dataset.Data(self.cfg)
        self.loader = DataLoader(self.data, batch_size=1, shuffle=False, num_workers=8)
        ## network
        self.net    = Network(self.cfg)
        self.net.train(False)
        self.net.cuda()


    def save(self):
        with torch.no_grad():
            for image0, image, mask, shape, name, size in self.loader:
                image = image.cuda().float()
                out = self.net(image, shape)
                out = F.interpolate(out, size=size[:-1], mode='bilinear')
                preds = torch.argmax(out, dim=1)
                preds = np.squeeze(preds)
                preds = 255 * preds.cpu().numpy()


                head  = '../eval/'+ self.cfg.datapath.split('/')[-1]
                if not os.path.exists(head):
                    os.makedirs(head)

                cv2.imwrite(head+'/'+name[0]+'.png', np.round(preds))



if __name__=='__main__':
    # for path in ['/data/ExpData/Test/DUT-OMROM/']:
    # for path in ['/data/ExpData/Test/COD/']:
    # for path in ['/data/ExpData/Test/CAMP/']:
    # for path in ['/data/ExpData/Test/SOC/']:
    # for path in ['/data/ExpData/Test/DUTS/']:
    for path in ['/data/ExpData/Test/THUR/']:
        t = Test(dataset, TFKDNet, path)
        t.save()
