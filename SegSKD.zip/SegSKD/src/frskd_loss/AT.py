import torch
import torch.nn as nn
import torch.nn.functional as F


class KLDivLoss(nn.Module):
    def __init__(self, ignore_index=255, T1 = 1,  T2 = 1, reduce=True):
        super(KLDivLoss, self).__init__()
        self.ignore_index = ignore_index
        self.T1 = T1
        self.T2 = T2
    def forward(self, logits_p, logits_q):
        assert logits_p.size() == logits_q.size()
        N, C, W, H = logits_p.shape
        # b, c = logits_p.size()
        T1 = self.T1
        T2 = self.T2
        logits_p = logits_p/T1
        logits_q = logits_q/T2
        p = F.softmax(logits_p.permute(0, 2, 3, 1).contiguous().view(-1, C), dim=1)
        q = F.softmax(logits_q.permute(0, 2, 3, 1).contiguous().view(-1, C), dim=1)

        b, c = p.size()
        epsilon = 1e-8
        _p = (p + epsilon * torch.ones(b, c).cuda()) / (1.0 + c * epsilon)
        _q = (q + epsilon * torch.ones(b, c).cuda()) / (1.0 + c * epsilon)
        loss = (1 ** 2) * torch.mean(torch.sum(_p * torch.log(_p / _q), dim=1))
        return loss

class Attention(nn.Module):
    def __init__(self, T, alpha, beta):
        super(Attention, self).__init__()
        self.p = 2
        self.kd = KLDivLoss(T1=1, T2=1)
        self.alpha = alpha
        self.beta = beta

    def forward(self, o_s, o_t, g_s, g_t):

        h, w = o_s.size(2), o_s.size(3)
        ph, pw = o_t.size(-2), o_t.size(-1)
        if ph != h or pw != w:
            o_t = F.upsample(input = o_t, size=(h, w), mode='bilinear')
        loss = self.alpha * self.kd(o_s, o_t)
        loss += self.beta * sum([self.at_loss(f_s, f_t.detach()) for f_s, f_t in zip(g_s, g_t)])

        return loss

    def at_loss(self, f_s, f_t):
        return (self.at(f_s) - self.at(f_t)).pow(2).mean()

    def at(self, f):
        return F.normalize(f.pow(self.p).mean(1).view(f.size(0), -1))
