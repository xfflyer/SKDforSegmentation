import os
import pandas as pd
import fnmatch
import numpy as np
import random

datapath="/data/Datasets/CamOD/HRN/Test"

def ReadSaveTrainTxt(Stra,Strb):
    print("Read :", Stra, Strb)
    a_list = fnmatch.filter(os.listdir(Stra), Strb)
    num = len(a_list)
    trainlist = []
    allindex = random.sample(range(0, num), num)
    # trainnum = int(num * 0.8)
    trainnum = 1000
    for i in range(0, trainnum):
        index=allindex[i]
        name = a_list[index]
        pname =  name
        trainlist.append(pname)
    print("Find = ", len(trainlist))
    df = pd.DataFrame(np.arange(len(trainlist)).reshape((len(trainlist), 1)), columns=['Addr'])
    df.Addr = trainlist
    df.to_csv('test.lst', columns=['Addr'], index=False, header=False)


ReadSaveTrainTxt(datapath, "*.jpg")