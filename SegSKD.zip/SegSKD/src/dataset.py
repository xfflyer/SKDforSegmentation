#!/usr/bin/python3
#coding=utf-8

import os
import cv2
import torch
import numpy as np
from torch.utils.data import Dataset

########################### Data Augmentation ###########################
class Normalize(object):
    def __init__(self, mean, std):
        self.mean = mean 
        self.std  = std
    
    def __call__(self, image, mask):
        image = (image - self.mean)/self.std
        mask /= 255

        return image, mask

class RandomCrop(object):
    def __call__(self, image, mask):
        H,W,_   = image.shape
        randw   = np.random.randint(W/8)
        randh   = np.random.randint(H/8)
        offseth = 0 if randh == 0 else np.random.randint(randh)
        offsetw = 0 if randw == 0 else np.random.randint(randw)
        p0, p1, p2, p3 = offseth, H+offseth-randh, offsetw, W+offsetw-randw
        return image[p0:p1, p2:p3, :], mask[p0:p1,p2:p3]

class RandomFlip(object):
    def __call__(self, image, mask):
        if np.random.randint(2)==0:
            return image[:,::-1,:], mask[:, ::-1]
        else:
            return image, mask

class Resize(object):
    def __init__(self, H, W):
        self.H = H
        self.W = W

    def __call__(self, image, mask):
        image = cv2.resize(image, dsize=(self.W, self.H), interpolation=cv2.INTER_LINEAR)
        mask  = cv2.resize( mask, dsize=(self.W, self.H), interpolation=cv2.INTER_LINEAR)
        return image, mask

class ToTensor(object):
    def __call__(self, image, mask):
        image = torch.from_numpy(image)
        image = image.permute(2, 0, 1)
        mask  = torch.from_numpy(mask)
        return image, mask


########################### Config File ###########################
class Config(object):
    def __init__(self, **kwargs):
        self.kwargs = kwargs
        self.mean   = np.array([[[124.55, 118.90, 102.94]]])
        self.std    = np.array([[[ 56.77,  55.97,  57.50]]])
        # self.model_version = 'resnet34'
        # self.pretrain_path = '/data/PreModels/resnet34-333f7ec4.pth'
        # self.model_version = 'resnet50'
        # self.pretrain = '/data/PreModels/resnet50-19c8e357.pth'
        ##CAM
        # self.mean   = np.array([[[0.4445561205175789*255, 0.42722236178158507*255, 0.3256907647665695*255]]])
        # self.std    = np.array([[[ 0.24789062521440783*255,  0.2360530929010359*255,  0.23911604977694859*255]]])
        ##CAMP
        # self.mean = np.array([[[0.46440234072086195 * 255, 0.4802259232423525 * 255, 0.36694580653194403 * 255]]])
        # self.std    = np.array([[[ 0.22688525324228667*255,  0.22651489450018664*255,  0.22214821926972658*255]]])
        ##Dut-OMROM
        print('\nParameters...')
        for k, v in self.kwargs.items():
            print('%-10s: %s'%(k, v))

    def __getattr__(self, name):
        if name in self.kwargs:
            return self.kwargs[name]
        else:
            return None


########################### Dataset Class ###########################
class Data(Dataset):
    def __init__(self, cfg):
        self.cfg        = cfg
        self.normalize  = Normalize(mean=cfg.mean, std=cfg.std)
        self.randomcrop = RandomCrop()
        self.randomflip = RandomFlip()
        self.resize     = Resize(288, 288)
        self.totensor   = ToTensor()

        self.list_path = cfg.datapath + cfg.mode+'.txt'
        self.img_list = [line.strip().split() for line in open(self.list_path)]
        self.samples = self.read_files()

    def read_files(self):
        files = []
        if 'test' in self.list_path:
            for item in self.img_list:
                image_path, label_path = item
                name = os.path.splitext(os.path.basename(image_path))[0]
                files.append({
                    "img": image_path,
                    "label": label_path,
                    "name": name,
                })
        else:
            for item in self.img_list:
                image_path, label_path = item
                name = os.path.splitext(os.path.basename(label_path))[0]
                files.append({
                    "img": image_path,
                    "label": label_path,
                    "name": name,
                    "weight": 1
                })
        return files

    def __getitem__(self, idx):
        item  = self.samples[idx]

        if self.cfg.mode == 'train':
            # item = self.samples[idx]
            imgname = os.path.join(self.cfg.datapath, item["img"])
            image = cv2.imread(imgname)[:, :, ::-1].astype(np.float32)
            size = image.shape
            image = cv2.resize(image, dsize=(288, 288))
            labelname = os.path.join(self.cfg.datapath, item["label"])
            mask = cv2.imread(labelname, 0).astype(np.float32)
            mask = cv2.resize(mask, dsize=(288, 288))
            _, mask = cv2.threshold(mask, 127, 255, cv2.THRESH_BINARY)
            shape = mask.shape

            image, mask = self.normalize(image, mask)
            image, mask = self.randomcrop(image, mask)
            image, mask = self.randomflip(image, mask)
            return image.copy(), mask.copy()
        else:
            # item = self.samples[idx]
            imgname = os.path.join(self.cfg.datapath, item["img"])
            image0 = cv2.imread(imgname)[:, :, ::-1].astype(np.float32)
            size = image0.shape
            image = cv2.resize(image0, dsize=(288, 288))

            labelname = os.path.join(self.cfg.datapath, item["label"])
            mask = cv2.imread(labelname, 0).astype(np.float32)
            mask = cv2.resize(mask, dsize=(288, 288))
            _, mask = cv2.threshold(mask, 127, 255, cv2.THRESH_BINARY)
            image, mask = self.normalize(image, mask)
            image, mask = self.resize(image, mask)
            image, mask = self.totensor(image, mask)
            shape = mask.shape
            name = item["name"]
            return image0, image, mask, shape, name, size

    def collate(self, batch):

        size = 288
        image, mask = [list(item) for item in zip(*batch)]
        for i in range(len(batch)):
            image[i] = cv2.resize(image[i], dsize=(size, size), interpolation=cv2.INTER_LINEAR)
            mask[i]  = cv2.resize(mask[i],  dsize=(size, size), interpolation=cv2.INTER_LINEAR)
        image = torch.from_numpy(np.stack(image, axis=0)).permute(0,3,1,2)
        mask  = torch.from_numpy(np.stack(mask, axis=0)).unsqueeze(1)
        return image, mask

    def __len__(self):
        return len(self.samples)


########################### Testing Script ###########################
if __name__=='__main__':
    import matplotlib.pyplot as plt
    plt.ion()

    cfg  = Config(mode='train', datapath='../data/DUTS')
    data = Data(cfg)
    for i in range(1000):
        image, mask = data[i]
        image       = image*cfg.std + cfg.mean
        plt.subplot(121)
        plt.imshow(np.uint8(image))
        plt.subplot(122)
        plt.imshow(mask)
        input()
