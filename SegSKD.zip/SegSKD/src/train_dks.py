#!/usr/bin/python3
#coding=utf-8

import sys
import datetime
sys.path.insert(0, '../')
sys.dont_write_bytecode = True

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from tensorboardX import SummaryWriter
import dataset
from net.net_dks  import DKSNet
from apex import amp
from core.criterion import CrossEntropy, KLDivLoss

import os
import numpy as np
import matplotlib.pyplot as plt

os.environ["CUDA_VISIBLE_DEVICES"] = "2"


def kd_loss_function(output, target_output, T):
    """Compute kd loss"""
    """
    para: output: middle ouptput logits.
    para: target_output: final output has divided by temperature and softmax.
    """

    output = output / T
    output_log_softmax = torch.log_softmax(output, dim=1)
    loss_kd = -torch.mean(torch.sum(output_log_softmax * target_output, dim=1))
    return loss_kd

def feature_loss_function(fea, target_fea):
    loss = (fea - target_fea)**2 * ((fea > 0) | (target_fea > 0)).float()
    return torch.abs(loss).mean()

# model_version='resnet50', pretrain='/data/PreModels/resnet50-19c8e357.pth',
def train(Dataset, Network):
    ## dataset
    # cfg    = Dataset.Config(datapath='/data/ExpData/Train/CAMP/', savepath='./out', model_version='resnet50', pretrain='/data/PreModels/resnet50-19c8e357.pth',
    #                         mode='train', batch=10, lr=0.05, momen=0.9, decay=5e-4, epoch=20)
    # cfg = Dataset.Config(datapath='/data/ExpData/Train/COD/', savepath='./out', model_version = 'resnet34', pretrain = '/data/PreModels/resnet34-333f7ec4.pth',
    #                      mode='train', batch=10, lr=0.05, momen=0.9, decay=5e-4, epoch=20)
    # cfg = Dataset.Config(datapath='/data/ExpData/Train/DUT-OMROM/', savepath='./out', model_version='resnet50', pretrain='/data/PreModels/resnet50-19c8e357.pth',
    #                      mode='train', batch=10, lr=0.05, momen=0.9, decay=5e-4, epoch=20)
    # cfg = Dataset.Config(datapath='/data/ExpData/Train/SOC/', savepath='./out',  model_version='resnet18', pretrain='/data/PreModels/resnet18-5c106cde.pth',
    #                      mode='train', batch=10, lr=0.05, momen=0.9, decay=5e-4, epoch=20)
    # cfg = Dataset.Config(datapath='/data/ExpData/Train/DUTS/', savepath='./out',   model_version = 'resnet34', pretrain = '/data/PreModels/resnet34-333f7ec4.pth',
    #                      mode='train', batch=10, lr=0.05, momen=0.9, decay=5e-4, epoch=20)
    cfg = Dataset.Config(datapath='/data/ExpData/Train/THUR/', savepath='./out',  model_version='resnet50', pretrain='/data/PreModels/resnet50-19c8e357.pth',
                         mode='train', batch=10, lr=0.05, momen=0.9, decay=5e-4, epoch=20)
    data   = Dataset.Data(cfg)
    loader = DataLoader(data, collate_fn=data.collate, batch_size=cfg.batch, shuffle=True)
    ## network
    net    = Network(cfg)
    net.train(True)
    # gpus = list([0,])
    # net = torch.nn.DataParallel(net, device_ids=gpus)
    if torch.cuda.is_available():
        net.cuda()

    ## parameter
    base, head = [], []
    for name, param in net.named_parameters():
        if 'bkbone.conv1' in name or 'bkbone.bn1' in name:
            print(name)
        elif 'bkbone' in name:
            base.append(param)
        else:
            head.append(param)
    optimizer      = torch.optim.SGD([{'params':base}, {'params':head}], lr=cfg.lr, momentum=cfg.momen, weight_decay=cfg.decay, nesterov=True)
    net, optimizer = amp.initialize(net, optimizer, opt_level='O2')
    sw             = SummaryWriter(cfg.savepath)
    global_step    = 0
    CE = CrossEntropy()
    KLD = KLDivLoss(T1=1, T2=1)
    for epoch in range(cfg.epoch):
        optimizer.param_groups[0]['lr'] = (1-abs((epoch+1)/(cfg.epoch+1)*2-1))*cfg.lr*0.1
        optimizer.param_groups[1]['lr'] = (1-abs((epoch+1)/(cfg.epoch+1)*2-1))*cfg.lr
        num = 1
        for step, (image, mask) in enumerate(loader):
            image, mask = image.cuda().float(), mask.cuda().float()
            pred, kdscore = net(image)
            pred = F.interpolate(pred, size=mask.size()[2:], mode='bilinear')
            loss0 = CE(pred, mask)

            for j, score in enumerate(kdscore):
                score = F.interpolate(kdscore[j], size=mask.size()[2:], mode='bilinear')
                kdscore[j] = score

            cslossbuf = []
            klossbuf = []
            for j, output in enumerate(kdscore):
                cslossbuf.append(CE(output, mask))
                for k, output_counterpart in enumerate(kdscore):
                    if output_counterpart is not output:
                        klossbuf.append(KLD(output_counterpart.detach(), output))
            celoss = sum(cslossbuf)/len(cslossbuf)
            kloss = sum(klossbuf) / len(klossbuf)
            kdloss = celoss + kloss
            loss = loss0 + kdloss

            optimizer.zero_grad()
            with amp.scale_loss(loss, optimizer) as scale_loss:
                scale_loss.backward()

            optimizer.step()

            if step%10 == 0:
                print('%s | step:%d/%d/%d | lr=%.6f | loss=%.6f'%(datetime.datetime.now(), global_step, epoch+1, cfg.epoch, optimizer.param_groups[0]['lr'], loss.item()))
                # if epoch == 0:
                #     torch.save(net.state_dict(), cfg.savepath + '/model2_epoch1_batch-' + str(num))
                #     num = num+1

        if (epoch + 1) == 20:
            torch.save(net.state_dict(), cfg.savepath + '/dks_model1-' + str(epoch + 1))

if __name__=='__main__':
    train(dataset, DKSNet)