#!/usr/bin/python3
#coding=utf-8

import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import torch.nn.functional as F
from inplace_abn import ABN
BatchNorm2d = ABN
BN_MOMENTUM = 0.01

def weight_init(module):
    for n, m in module.named_children():
        print('initialize: '+n)
        if isinstance(m, nn.Conv2d):
            nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, (nn.BatchNorm2d, nn.InstanceNorm2d)):
            nn.init.ones_(m.weight)
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Linear):
            nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Sequential):
            weight_init(m)
        elif isinstance(m, nn.ReLU):
            pass
        elif isinstance(m, nn.Dropout2d):
            pass
        elif isinstance(m, PSPModule):
            pass
        elif isinstance(m, CoordAtt):
            pass
        elif isinstance(m, CBAM):
            pass
        else:
            m.initialize()

class PSPModule(nn.Module):
    """
    Reference:
        Zhao, Hengshuang, et al. *"Pyramid scene parsing network."*
    """
    def __init__(self, features, out_features=512, sizes=(1, 2, 3, 6)):
        super(PSPModule, self).__init__()

        self.stages = []
        self.stages = nn.ModuleList([self._make_stage(features, out_features, size) for size in sizes])
        self.bottleneck = nn.Sequential(
            nn.Conv2d(features+len(sizes)*out_features, out_features, kernel_size=3, padding=1, dilation=1, bias=False),
            BatchNorm2d(out_features),
            nn.Dropout2d(0.1)
            )

    def _make_stage(self, features, out_features, size):
        prior = nn.AdaptiveAvgPool2d(output_size=(size, size))
        conv = nn.Conv2d(features, out_features, kernel_size=1, bias=False)
        bn = BatchNorm2d(out_features)
        return nn.Sequential(prior, conv, bn)

    def forward(self, feats):
        h, w = feats.size(2), feats.size(3)
        priors = [F.upsample(input=stage(feats), size=(h, w), mode='bilinear', align_corners=True) for stage in self.stages] + [feats]
        bottle = self.bottleneck(torch.cat(priors, 1))
        return bottle


class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, in_planes, planes, stride=1):
        super(BasicBlock, self).__init__()
        self.conv1 = nn.Conv2d(in_planes, planes, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(planes)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(planes)

        self.shortcut = nn.Sequential()
        if stride != 1 or in_planes != self.expansion*planes:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_planes, self.expansion*planes, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(self.expansion*planes)
            )

    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out += self.shortcut(x)
        out = F.relu(out)
        return out


class Bottleneck(nn.Module):
    def __init__(self, inplanes, planes, stride=1, downsample=None, dilation=1):
        super(Bottleneck, self).__init__()
        self.conv1      = nn.Conv2d(inplanes, planes, kernel_size=1, bias=False)
        self.bn1        = nn.BatchNorm2d(planes)
        self.conv2      = nn.Conv2d(planes, planes, kernel_size=3, stride=stride, padding=(3*dilation-1)//2, bias=False, dilation=dilation)
        self.bn2        = nn.BatchNorm2d(planes)
        self.conv3      = nn.Conv2d(planes, planes*4, kernel_size=1, bias=False)
        self.bn3        = nn.BatchNorm2d(planes*4)
        self.downsample = downsample

    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)), inplace=True)
        out = F.relu(self.bn2(self.conv2(out)), inplace=True)
        out = self.bn3(self.conv3(out))
        if self.downsample is not None:
            x = self.downsample(x)
        return F.relu(out+x, inplace=True)

class ResNet(nn.Module):
    def __init__(self, name, num_blocks, path):
        super(ResNet, self).__init__()

        self.path = path
        if name == 'resnet18':
            self.in_planes = 64
            self.conv1 = nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3, bias=False)
            self.bn1 = nn.BatchNorm2d(64)
            self.layer1 = self._make_layer(BasicBlock, 64, num_blocks[0], stride=1)
            self.layer2 = self._make_layer(BasicBlock, 128, num_blocks[1], stride=2)
            self.layer3 = self._make_layer(BasicBlock, 256, num_blocks[2], stride=2)
            self.layer4 = self._make_layer(BasicBlock, 512, num_blocks[3], stride=2)
        elif name == 'resnet34':
            self.in_planes = 64
            self.conv1 = nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3, bias=False)
            self.bn1 = nn.BatchNorm2d(64)
            self.bn1 = nn.BatchNorm2d(64)
            self.layer1 = self._make_layer(BasicBlock, 64, num_blocks[0], stride=1)
            self.layer2 = self._make_layer(BasicBlock, 128, num_blocks[1], stride=2)
            self.layer3 = self._make_layer(BasicBlock, 256, num_blocks[2], stride=2)
            self.layer4 = self._make_layer(BasicBlock, 512, num_blocks[3], stride=2)

        elif name == 'resnet50':
            self.inplanes = 64
            self.conv1 = nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3, bias=False)
            self.bn1 = nn.BatchNorm2d(64)

            self.path = path
            self.layer1 = self.make_layer(64, num_blocks[0], stride=1, dilation=1)
            self.layer2 = self.make_layer(128, num_blocks[1], stride=2, dilation=1)
            self.layer3 = self.make_layer(256, num_blocks[2], stride=2, dilation=1)
            self.layer4 = self.make_layer(512, num_blocks[3], stride=2, dilation=1)


    def make_layer(self, planes, blocks, stride, dilation):
        downsample    = nn.Sequential(nn.Conv2d(self.inplanes, planes*4, kernel_size=1, stride=stride, bias=False), nn.BatchNorm2d(planes*4))
        layers        = [Bottleneck(self.inplanes, planes, stride, downsample, dilation=dilation)]
        self.inplanes = planes*4
        for _ in range(1, blocks):
            layers.append(Bottleneck(self.inplanes, planes, dilation=dilation))
        return nn.Sequential(*layers)

    def _make_layer(self, block, planes, num_blocks, stride):
        strides = [stride] + [1] * (num_blocks - 1)
        layers = []
        for stride in strides:
            layers.append(block(self.in_planes, planes, stride))
            self.in_planes = planes * block.expansion
        return nn.Sequential(*layers)

    def forward(self, x):
        out1 = F.relu(self.bn1(self.conv1(x)), inplace=True)
        out1 = F.max_pool2d(out1, kernel_size=3, stride=2, padding=1)
        out2 = self.layer1(out1)
        out3 = self.layer2(out2)
        out4 = self.layer3(out3)
        out5 = self.layer4(out4)
        return out2, out3, out4, out5

    def initialize(self):
        self.load_state_dict(torch.load(self.path), strict=False)


class CFM(nn.Module):
    def __init__(self, channelnum):
        super(CFM, self).__init__()
        self.conv1h = nn.Conv2d(channelnum, channelnum, kernel_size=3, stride=1, padding=1)
        self.bn1h   = nn.BatchNorm2d(channelnum)
        self.conv2h = nn.Conv2d(channelnum, channelnum, kernel_size=3, stride=1, padding=1)
        self.bn2h   = nn.BatchNorm2d(channelnum)
        self.conv3h = nn.Conv2d(channelnum, channelnum, kernel_size=3, stride=1, padding=1)
        self.bn3h   = nn.BatchNorm2d(channelnum)
        self.conv4h = nn.Conv2d(channelnum, channelnum, kernel_size=3, stride=1, padding=1)
        self.bn4h   = nn.BatchNorm2d(channelnum)

        self.conv1v = nn.Conv2d(channelnum, channelnum, kernel_size=3, stride=1, padding=1)
        self.bn1v   = nn.BatchNorm2d(channelnum)
        self.conv2v = nn.Conv2d(channelnum, channelnum, kernel_size=3, stride=1, padding=1)
        self.bn2v   = nn.BatchNorm2d(channelnum)
        self.conv3v = nn.Conv2d(channelnum, channelnum, kernel_size=3, stride=1, padding=1)
        self.bn3v   = nn.BatchNorm2d(channelnum)
        self.conv4v = nn.Conv2d(channelnum, channelnum, kernel_size=3, stride=1, padding=1)
        self.bn4v   = nn.BatchNorm2d(channelnum)

    def forward(self, left, down):
        if down.size()[2:] != left.size()[2:]:
            down = F.interpolate(down, size=left.size()[2:], mode='bilinear')
        out1h = F.relu(self.bn1h(self.conv1h(left )), inplace=True)
        out2h = F.relu(self.bn2h(self.conv2h(out1h)), inplace=True)
        out1v = F.relu(self.bn1v(self.conv1v(down )), inplace=True)
        out2v = F.relu(self.bn2v(self.conv2v(out1v)), inplace=True)
        fuse  = out2h*out2v
        out3h = F.relu(self.bn3h(self.conv3h(fuse )), inplace=True)+out1h
        out4h = F.relu(self.bn4h(self.conv4h(out3h)), inplace=True)
        out3v = F.relu(self.bn3v(self.conv3v(fuse )), inplace=True)+out1v
        out4v = F.relu(self.bn4v(self.conv4v(out3v)), inplace=True)
        return out4h, out4v

    def initialize(self):
        weight_init(self)



class Decoder(nn.Module):
    def __init__(self, channelnum):
        super(Decoder, self).__init__()
        self.cfm45  = CFM(channelnum)
        self.cfm34  = CFM(channelnum)
        self.cfm23  = CFM(channelnum)

    def forward(self, out2h, out3h, out4h, out5v, fback=None):

        out4h, out4v = self.cfm45(out4h, out5v)
        out3h, out3v = self.cfm34(out3h, out4v)
        out2h, pred  = self.cfm23(out2h, out3v)

        # return out2h, out3h, out4h, out4v, pred
        return out2h, out3h, out4h, out5v, pred

    def initialize(self):
        weight_init(self)



class h_sigmoid(nn.Module):
    def __init__(self, inplace=True):
        super(h_sigmoid, self).__init__()
        self.relu = nn.ReLU6(inplace=inplace)

    def forward(self, x):
        return self.relu(x + 3) / 6


class h_swish(nn.Module):
    def __init__(self, inplace=True):
        super(h_swish, self).__init__()
        self.sigmoid = h_sigmoid(inplace=inplace)

    def forward(self, x):
        return x * self.sigmoid(x)

class CoordAtt(nn.Module):
    def __init__(self, inp, oup, reduction=32):
        super(CoordAtt, self).__init__()
        self.pool_h = nn.AdaptiveAvgPool2d((None, 1))
        self.pool_w = nn.AdaptiveAvgPool2d((1, None))

        mip = max(8, inp // reduction)

        self.conv1 = nn.Conv2d(inp, mip, kernel_size=1, stride=1, padding=0)
        self.bn1 = nn.BatchNorm2d(mip)
        self.act = h_swish()

        self.conv_h = nn.Conv2d(mip, oup, kernel_size=1, stride=1, padding=0)
        self.conv_w = nn.Conv2d(mip, oup, kernel_size=1, stride=1, padding=0)

    def forward(self, x):
        identity = x

        n, c, h, w = x.size()
        x_h = self.pool_h(x)
        x_w = self.pool_w(x).permute(0, 1, 3, 2)

        y = torch.cat([x_h, x_w], dim=2)
        y = self.conv1(y)
        y = self.bn1(y)
        y = self.act(y)

        x_h, x_w = torch.split(y, [h, w], dim=2)
        x_w = x_w.permute(0, 1, 3, 2)

        a_h = self.conv_h(x_h).sigmoid()
        a_w = self.conv_w(x_w).sigmoid()

        out = identity * a_w * a_h

        return out

class BasicConv(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1, groups=1, relu=True, bn=True, bias=False):
        super(BasicConv, self).__init__()
        self.out_channels = out_planes
        self.conv = nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=padding, dilation=dilation, groups=groups, bias=bias)
        self.bn = nn.BatchNorm2d(out_planes,eps=1e-5, momentum=0.01, affine=True) if bn else None
        self.relu = nn.ReLU() if relu else None

    def forward(self, x):
        x = self.conv(x)
        if self.bn is not None:
            x = self.bn(x)
        if self.relu is not None:
            x = self.relu(x)
        return x

class Flatten(nn.Module):
    def forward(self, x):
        return x.view(x.size(0), -1)

class ChannelGate(nn.Module):
    def __init__(self, gate_channels, reduction_ratio=16, pool_types=['avg', 'max']):
        super(ChannelGate, self).__init__()
        self.gate_channels = gate_channels
        self.mlp = nn.Sequential(
            Flatten(),
            nn.Linear(gate_channels, gate_channels // reduction_ratio),
            nn.ReLU(),
            nn.Linear(gate_channels // reduction_ratio, gate_channels)
            )
        self.pool_types = pool_types
    def forward(self, x):
        channel_att_sum = None
        for pool_type in self.pool_types:
            if pool_type=='avg':
                avg_pool = F.avg_pool2d( x, (x.size(2), x.size(3)), stride=(x.size(2), x.size(3)))
                channel_att_raw = self.mlp( avg_pool )
            elif pool_type=='max':
                max_pool = F.max_pool2d( x, (x.size(2), x.size(3)), stride=(x.size(2), x.size(3)))
                channel_att_raw = self.mlp( max_pool )
            elif pool_type=='lp':
                lp_pool = F.lp_pool2d( x, 2, (x.size(2), x.size(3)), stride=(x.size(2), x.size(3)))
                channel_att_raw = self.mlp( lp_pool )
            elif pool_type=='lse':
                # LSE pool only
                lse_pool = logsumexp_2d(x)
                channel_att_raw = self.mlp( lse_pool )

            if channel_att_sum is None:
                channel_att_sum = channel_att_raw
            else:
                channel_att_sum = channel_att_sum + channel_att_raw

        scale = F.sigmoid( channel_att_sum ).unsqueeze(2).unsqueeze(3).expand_as(x)
        return x * scale

def logsumexp_2d(tensor):
    tensor_flatten = tensor.view(tensor.size(0), tensor.size(1), -1)
    s, _ = torch.max(tensor_flatten, dim=2, keepdim=True)
    outputs = s + (tensor_flatten - s).exp().sum(dim=2, keepdim=True).log()
    return outputs

class ChannelPool(nn.Module):
    def forward(self, x):
        return torch.cat( (torch.max(x, 1)[0].unsqueeze(1), torch.mean(x,1).unsqueeze(1)), dim=1 )

class SpatialGate(nn.Module):
    def __init__(self):
        super(SpatialGate, self).__init__()
        kernel_size = 7
        self.compress = ChannelPool()
        self.spatial = BasicConv(2, 1, kernel_size, stride=1, padding=(kernel_size-1) // 2, relu=False)
    def forward(self, x):
        x_compress = self.compress(x)
        x_out = self.spatial(x_compress)
        scale = F.sigmoid(x_out) # broadcasting
        return x * scale

class CBAM(nn.Module):
    def __init__(self, gate_channels, reduction_ratio=16, pool_types=['avg', 'max'], no_spatial=False):
        super(CBAM, self).__init__()
        self.ChannelGate = ChannelGate(gate_channels, reduction_ratio, pool_types)
        self.no_spatial = no_spatial
        if not no_spatial:
            self.SpatialGate = SpatialGate()
    def forward(self, x):
        x_out = self.ChannelGate(x)
        if not self.no_spatial:
            x_out = self.SpatialGate(x_out)
        return x_out


class PSPSkdNet(nn.Module):
    def __init__(self, cfg):
        super(PSPSkdNet, self).__init__()
        self.cfg = cfg

        if self.cfg.model_version == 'resnet18':
            self.bkbone = ResNet(self.cfg.model_version, [2, 2, 2, 2], cfg.pretrain)
            self.decoder = Decoder(16)
            self.pspmodule1 = PSPModule(64, 16)
            self.pspmodule2 = PSPModule(128, 16)
            self.pspmodule3 = PSPModule(256, 16)
            self.pspmodule4 = PSPModule(512, 16)
            self.pspmodule0 = PSPModule(960, 16)

            self.cattention1 = CBAM(16, 4, ['avg', 'max'])
            self.cattention2 = CBAM(16, 4, ['avg', 'max'])
            self.cattention3 = CBAM(16, 4, ['avg', 'max'])
            self.cattention4 = CBAM(16, 4, ['avg', 'max'])
            self.cattention0 = CBAM(16, 4, ['avg', 'max'])

            self.linear1 = nn.Sequential(
                nn.Conv2d(16, 16, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(16, 2, kernel_size=1)
            )
            self.linear2 = nn.Sequential(
                nn.Conv2d(16, 16, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(16, 2, kernel_size=1)
            )
            self.linear3 = nn.Sequential(
                nn.Conv2d(16, 16, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(16, 2, kernel_size=1)
            )
            self.linear4 = nn.Sequential(
                nn.Conv2d(16, 16, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(16, 2, kernel_size=1)
            )
            self.linear0 = nn.Sequential(
                nn.Conv2d(16, 16, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(16, 2, kernel_size=1)
            )

            self.squeeze = nn.Sequential(nn.Conv2d(960, 16, 1),
                                         nn.BatchNorm2d(16),
                                         nn.ReLU(inplace=True)
                                         )

            self.fullinear = nn.Sequential(
                nn.Conv2d(16, 16, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(16, 2, kernel_size=1)
            )
        elif self.cfg.model_version == 'resnet34':
            self.bkbone = ResNet(self.cfg.model_version, [3, 4, 6, 3], cfg.pretrain)
            self.decoder = Decoder(16)
            self.pspmodule1 = PSPModule(64, 16)
            self.pspmodule2 = PSPModule(128, 16)
            self.pspmodule3 = PSPModule(256, 16)
            self.pspmodule4 = PSPModule(512, 16)
            self.pspmodule0 = PSPModule(960, 16)

            self.cattention1 = CBAM(16, 4, ['avg', 'max'])
            self.cattention2 = CBAM(16, 4, ['avg', 'max'])
            self.cattention3 = CBAM(16, 4, ['avg', 'max'])
            self.cattention4 = CBAM(16, 4, ['avg', 'max'])
            self.cattention0 = CBAM(16, 4, ['avg', 'max'])

            self.linear1 = nn.Sequential(
                nn.Conv2d(16, 16, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(16, 2, kernel_size=1)
            )
            self.linear2 = nn.Sequential(
                nn.Conv2d(16, 16, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(16, 2, kernel_size=1)
            )
            self.linear3 = nn.Sequential(
                nn.Conv2d(16, 16, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(16, 2, kernel_size=1)
            )
            self.linear4 = nn.Sequential(
                nn.Conv2d(16, 16, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(16, 2, kernel_size=1)
            )
            self.linear0 = nn.Sequential(
                nn.Conv2d(16, 16, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(16, 2, kernel_size=1)
            )

            self.squeeze = nn.Sequential(nn.Conv2d(960, 16, 1),
                                         nn.BatchNorm2d(16),
                                         nn.ReLU(inplace=True)
                                         )

            self.fullinear = nn.Sequential(
                nn.Conv2d(16, 16, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(16, 2, kernel_size=1)
            )

        elif self.cfg.model_version == 'resnet50':
            self.bkbone = ResNet(self.cfg.model_version, [3, 4, 6, 3], cfg.pretrain)
            self.decoder = Decoder(64)

            self.pspmodule1 = PSPModule(256, 64)
            self.pspmodule2 = PSPModule(512, 64)
            self.pspmodule3 = PSPModule(1024, 64)
            self.pspmodule4 = PSPModule(2048, 64)
            self.pspmodule0 = PSPModule(3840, 64)

            self.cattention1 = CBAM(64, 8, ['avg', 'max'])
            self.cattention2 = CBAM(64, 8, ['avg', 'max'])
            self.cattention3 = CBAM(64, 8, ['avg', 'max'])
            self.cattention4 = CBAM(64, 8, ['avg', 'max'])
            self.cattention0 = CBAM(64, 8, ['avg', 'max'])


            self.linear1 = nn.Sequential(
                nn.Conv2d(64, 64, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(64, 2, kernel_size=1)
            )
            self.linear2 = nn.Sequential(
                nn.Conv2d(64, 64, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(64, 2, kernel_size=1)
            )
            self.linear3 = nn.Sequential(
                nn.Conv2d(64, 64, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(64, 2, kernel_size=1)
            )
            self.linear4 = nn.Sequential(
                nn.Conv2d(64, 64, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(64, 2, kernel_size=1)
            )
            self.linear0 = nn.Sequential(
                nn.Conv2d(64, 64, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(64, 2, kernel_size=1)
            )

            self.squeeze = nn.Sequential(nn.Conv2d(3840, 64, 1),
                                         nn.BatchNorm2d(64),
                                         nn.ReLU(inplace=True)
                                         )

            self.fullinear = nn.Sequential(
                nn.Conv2d(64, 64, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(64, 2, kernel_size=1)
            )

        elif self.cfg.model_version == 'resnet101':
            self.bkbone = ResNet(Bottleneck, [3, 4, 6, 3])
        elif self.cfg.model_version == 'resnet152':
            self.bkbone = ResNet(Bottleneck, [3, 8, 36, 3])
        self.initialize()

    def forward(self, x, shape=None):
        out2h, out3h, out4h, out5v = self.bkbone(x)


        featpsp = []
        featpsp.append(self.pspmodule1(out2h))
        featpsp.append(self.pspmodule2(out3h))
        featpsp.append(self.pspmodule3(out4h))
        featpsp.append(self.pspmodule4(out5v))
        dout1, dout2, dout3, dout4, pred1 = self.decoder(featpsp[0],
                                                         featpsp[1],
                                                         featpsp[2],
                                                         featpsp[3])
        # featcpd = []
        # featcpd.append(dout1)
        # featcpd.append(dout2)
        # featcpd.append(dout3)
        # featcpd.append(dout4)

        featattpsp = []
        dout1 = self.cattention1(dout1)
        featattpsp.append(dout1.mean(dim=1, keepdim=True))
        dout2 = self.cattention2(dout2)
        featattpsp.append(dout2.mean(dim=1, keepdim=True))
        dout3 = self.cattention3(dout3)
        featattpsp.append(dout3.mean(dim=1, keepdim=True))
        dout4 = self.cattention4(dout4)
        featattpsp.append(dout4.mean(dim=1, keepdim=True))

        defeatscore = []
        defeatscore.append(self.linear1(dout1))
        defeatscore.append(self.linear2(dout2))
        defeatscore.append(self.linear3(dout3))
        defeatscore.append(self.linear4(dout4))

        # scorebackbone = []
        # scorebackbone.append(self.backbonelinear1(out2h))
        # scorebackbone.append(self.backbonelinear2(out3h))
        # scorebackbone.append(self.backbonelinear3(out4h))
        # scorebackbone.append(self.backbonelioutfeatnear4(out5v))

        out3h = F.interpolate(out3h, size=out2h.size()[2:], mode='bilinear')
        out4h = F.interpolate(out4h, size=out2h.size()[2:], mode='bilinear')
        out5v = F.interpolate(out5v, size=out2h.size()[2:], mode='bilinear')
        outfeat = torch.cat([out2h, out3h, out4h, out5v], 1)
        # pred = self.fullinear(outfeat)
        featsqueeze = self.squeeze(outfeat)
        pred = self.fullinear(featsqueeze)

        featpsp.append(self.pspmodule0(outfeat))
        featattpsp.append(self.cattention0(featpsp[-1]))
        outfeat0 = featattpsp[-1]

        defeatscore.append(self.linear0(outfeat0))

        # scorebackbone.append(self.backbonelinear0(outfeat))

        featbackbone=[]
        featbackbone.append(out2h.mean(dim=1, keepdim=True))
        featbackbone.append(out3h.mean(dim=1, keepdim=True))
        featbackbone.append(out4h.mean(dim=1, keepdim=True))
        featbackbone.append(out5v.mean(dim=1, keepdim=True))
        featbackbone.append(outfeat.mean(dim=1, keepdim=True))

        # return pred, defeatscore, featattpsp, featcpd, featpsp

        return pred, defeatscore, featattpsp, featbackbone

    def initialize(self):
        if self.cfg.snapshot:
            self.load_state_dict(torch.load(self.cfg.snapshot))
        else:
            weight_init(self)

class PSPSkdNet(nn.Module):
    def __init__(self, cfg):
        super(PSPSkdNet, self).__init__()
        self.cfg = cfg

        if self.cfg.model_version == 'resnet18':
            self.bkbone = ResNet(self.cfg.model_version, [2, 2, 2, 2], cfg.pretrain)
            self.decoder = Decoder(16)
            self.pspmodule1 = PSPModule(64, 16)
            self.pspmodule2 = PSPModule(128, 16)
            self.pspmodule3 = PSPModule(256, 16)
            self.pspmodule4 = PSPModule(512, 16)
            self.pspmodule0 = PSPModule(960, 16)

            self.cattention1 = CBAM(16, 4, ['avg', 'max'])
            self.cattention2 = CBAM(16, 4, ['avg', 'max'])
            self.cattention3 = CBAM(16, 4, ['avg', 'max'])
            self.cattention4 = CBAM(16, 4, ['avg', 'max'])
            self.cattention0 = CBAM(16, 4, ['avg', 'max'])

            self.linear1 = nn.Sequential(
                nn.Conv2d(16, 16, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(16, 2, kernel_size=1)
            )
            self.linear2 = nn.Sequential(
                nn.Conv2d(16, 16, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(16, 2, kernel_size=1)
            )
            self.linear3 = nn.Sequential(
                nn.Conv2d(16, 16, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(16, 2, kernel_size=1)
            )
            self.linear4 = nn.Sequential(
                nn.Conv2d(16, 16, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(16, 2, kernel_size=1)
            )
            self.linear0 = nn.Sequential(
                nn.Conv2d(16, 16, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(16, 2, kernel_size=1)
            )

            self.squeeze = nn.Sequential(nn.Conv2d(960, 16, 1),
                                         nn.BatchNorm2d(16),
                                         nn.ReLU(inplace=True)
                                         )

            self.fullinear = nn.Sequential(
                nn.Conv2d(16, 16, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(16, 2, kernel_size=1)
            )
        elif self.cfg.model_version == 'resnet34':
            self.bkbone = ResNet(self.cfg.model_version, [3, 4, 6, 3], cfg.pretrain)
            self.decoder = Decoder(16)
            self.pspmodule1 = PSPModule(64, 16)
            self.pspmodule2 = PSPModule(128, 16)
            self.pspmodule3 = PSPModule(256, 16)
            self.pspmodule4 = PSPModule(512, 16)
            self.pspmodule0 = PSPModule(960, 16)

            self.cattention1 = CBAM(16, 4, ['avg', 'max'])
            self.cattention2 = CBAM(16, 4, ['avg', 'max'])
            self.cattention3 = CBAM(16, 4, ['avg', 'max'])
            self.cattention4 = CBAM(16, 4, ['avg', 'max'])
            self.cattention0 = CBAM(16, 4, ['avg', 'max'])

            self.linear1 = nn.Sequential(
                nn.Conv2d(16, 16, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(16, 2, kernel_size=1)
            )
            self.linear2 = nn.Sequential(
                nn.Conv2d(16, 16, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(16, 2, kernel_size=1)
            )
            self.linear3 = nn.Sequential(
                nn.Conv2d(16, 16, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(16, 2, kernel_size=1)
            )
            self.linear4 = nn.Sequential(
                nn.Conv2d(16, 16, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(16, 2, kernel_size=1)
            )
            self.linear0 = nn.Sequential(
                nn.Conv2d(16, 16, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(16, 2, kernel_size=1)
            )

            self.squeeze = nn.Sequential(nn.Conv2d(960, 16, 1),
                                         nn.BatchNorm2d(16),
                                         nn.ReLU(inplace=True)
                                         )

            self.fullinear = nn.Sequential(
                nn.Conv2d(16, 16, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(16, 2, kernel_size=1)
            )

        elif self.cfg.model_version == 'resnet50':
            self.bkbone = ResNet(self.cfg.model_version, [3, 4, 6, 3], cfg.pretrain)
            self.decoder = Decoder(64)

            self.pspmodule1 = PSPModule(256, 64)
            self.pspmodule2 = PSPModule(512, 64)
            self.pspmodule3 = PSPModule(1024, 64)
            self.pspmodule4 = PSPModule(2048, 64)
            self.pspmodule0 = PSPModule(3840, 64)

            self.cattention1 = CBAM(64, 8, ['avg', 'max'])
            self.cattention2 = CBAM(64, 8, ['avg', 'max'])
            self.cattention3 = CBAM(64, 8, ['avg', 'max'])
            self.cattention4 = CBAM(64, 8, ['avg', 'max'])
            self.cattention0 = CBAM(64, 8, ['avg', 'max'])


            self.linear1 = nn.Sequential(
                nn.Conv2d(64, 64, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(64, 2, kernel_size=1)
            )
            self.linear2 = nn.Sequential(
                nn.Conv2d(64, 64, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(64, 2, kernel_size=1)
            )
            self.linear3 = nn.Sequential(
                nn.Conv2d(64, 64, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(64, 2, kernel_size=1)
            )
            self.linear4 = nn.Sequential(
                nn.Conv2d(64, 64, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(64, 2, kernel_size=1)
            )
            self.linear0 = nn.Sequential(
                nn.Conv2d(64, 64, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(64, 2, kernel_size=1)
            )

            self.squeeze = nn.Sequential(nn.Conv2d(3840, 64, 1),
                                         nn.BatchNorm2d(64),
                                         nn.ReLU(inplace=True)
                                         )

            self.fullinear = nn.Sequential(
                nn.Conv2d(64, 64, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(64, 2, kernel_size=1)
            )

        elif self.cfg.model_version == 'resnet101':
            self.bkbone = ResNet(Bottleneck, [3, 4, 6, 3])
        elif self.cfg.model_version == 'resnet152':
            self.bkbone = ResNet(Bottleneck, [3, 8, 36, 3])
        self.initialize()

    def forward(self, x, shape=None):
        out2h, out3h, out4h, out5v = self.bkbone(x)


        featpsp = []
        featpsp.append(self.pspmodule1(out2h))
        featpsp.append(self.pspmodule2(out3h))
        featpsp.append(self.pspmodule3(out4h))
        featpsp.append(self.pspmodule4(out5v))
        dout1, dout2, dout3, dout4, pred1 = self.decoder(featpsp[0],
                                                         featpsp[1],
                                                         featpsp[2],
                                                         featpsp[3])
        # featcpd = []
        # featcpd.append(dout1)
        # featcpd.append(dout2)
        # featcpd.append(dout3)
        # featcpd.append(dout4)

        featattpsp = []
        dout1 = self.cattention1(dout1)
        featattpsp.append(dout1.mean(dim=1, keepdim=True))
        dout2 = self.cattention2(dout2)
        featattpsp.append(dout2.mean(dim=1, keepdim=True))
        dout3 = self.cattention3(dout3)
        featattpsp.append(dout3.mean(dim=1, keepdim=True))
        dout4 = self.cattention4(dout4)
        featattpsp.append(dout4.mean(dim=1, keepdim=True))

        defeatscore = []
        defeatscore.append(self.linear1(dout1))
        defeatscore.append(self.linear2(dout2))
        defeatscore.append(self.linear3(dout3))
        defeatscore.append(self.linear4(dout4))

        # scorebackbone = []
        # scorebackbone.append(self.backbonelinear1(out2h))
        # scorebackbone.append(self.backbonelinear2(out3h))
        # scorebackbone.append(self.backbonelinear3(out4h))
        # scorebackbone.append(self.backbonelioutfeatnear4(out5v))

        out3h = F.interpolate(out3h, size=out2h.size()[2:], mode='bilinear')
        out4h = F.interpolate(out4h, size=out2h.size()[2:], mode='bilinear')
        out5v = F.interpolate(out5v, size=out2h.size()[2:], mode='bilinear')
        outfeat = torch.cat([out2h, out3h, out4h, out5v], 1)
        # pred = self.fullinear(outfeat)
        featsqueeze = self.squeeze(outfeat)
        pred = self.fullinear(featsqueeze)

        featpsp.append(self.pspmodule0(outfeat))
        featattpsp.append(self.cattention0(featpsp[-1]))
        outfeat0 = featattpsp[-1]

        defeatscore.append(self.linear0(outfeat0))

        # scorebackbone.append(self.backbonelinear0(outfeat))

        featbackbone=[]
        featbackbone.append(out2h.mean(dim=1, keepdim=True))
        featbackbone.append(out3h.mean(dim=1, keepdim=True))
        featbackbone.append(out4h.mean(dim=1, keepdim=True))
        featbackbone.append(out5v.mean(dim=1, keepdim=True))
        featbackbone.append(outfeat.mean(dim=1, keepdim=True))

        # return pred, defeatscore, featattpsp, featcpd, featpsp

        return pred, defeatscore, featattpsp, featbackbone

    def initialize(self):
        if self.cfg.snapshot:
            self.load_state_dict(torch.load(self.cfg.snapshot))
        else:
            weight_init(self)


