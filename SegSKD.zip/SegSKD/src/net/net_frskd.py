#!/usr/bin/python3
#coding=utf-8

import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import torch.nn.functional as F
from inplace_abn import ABN
import math
BatchNorm2d = ABN
BN_MOMENTUM = 0.01

def weight_init(module):
    for n, m in module.named_children():
        print('initialize: '+n)
        if isinstance(m, nn.Conv2d):
            nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, (nn.BatchNorm2d, nn.InstanceNorm2d)):
            nn.init.ones_(m.weight)
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Linear):
            nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Sequential):
            weight_init(m)
        elif isinstance(m, nn.ReLU):
            pass
        elif isinstance(m, nn.Dropout2d):
            pass
        elif isinstance(m, BiFPNc):
            pass
        else:
            m.initialize()

class MaxPool2dStaticSamePadding(nn.Module):
    def __init__(self, *args, **kwargs):
        super().__init__()
        self.pool = nn.MaxPool2d(*args, **kwargs)
        self.stride = self.pool.stride
        self.kernel_size = self.pool.kernel_size

        if isinstance(self.stride, int):
            self.stride = [self.stride] * 2
        elif len(self.stride) == 1:
            self.stride = [self.stride[0]] * 2

        if isinstance(self.kernel_size, int):
            self.kernel_size = [self.kernel_size] * 2
        elif len(self.kernel_size) == 1:
            self.kernel_size = [self.kernel_size[0]] * 2

    def forward(self, x):
        h, w = x.shape[-2:]

        extra_h = (math.ceil(w / self.stride[1]) - 1) * self.stride[1] - w + self.kernel_size[1]
        extra_v = (math.ceil(h / self.stride[0]) - 1) * self.stride[0] - h + self.kernel_size[0]

        left = extra_h // 2
        right = extra_h - left
        top = extra_v // 2
        bottom = extra_v - top

        x = F.pad(x, [left, right, top, bottom])

        x = self.pool(x)
        return x

class DepthConvBlock(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=1, stride=1, padding=0, depth=1):
        super(DepthConvBlock, self).__init__()
        conv = []
        if kernel_size == 1:
            conv.append(nn.Sequential(
                nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=1, padding=0,
                          bias=False),
                nn.BatchNorm2d(out_channels),
                nn.ReLU(),
            ))
        else:
            conv.append(nn.Sequential(
                nn.Conv2d(in_channels, in_channels, kernel_size=kernel_size, stride=stride, padding=padding,
                          bias=False, groups=in_channels),
                nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=1, padding=0, bias=False),
                nn.BatchNorm2d(out_channels),
            ))
            for i in range(depth-1):
                conv.append(nn.Sequential(
                    nn.ReLU(),
                    nn.Conv2d(out_channels, out_channels, kernel_size=kernel_size, stride=stride, padding=padding,
                              bias=False, groups=out_channels),
                    nn.Conv2d(out_channels, out_channels, kernel_size=1, stride=1, padding=0, bias=False),
                    nn.BatchNorm2d(out_channels),
                ))
        self.conv = nn.Sequential(*conv)

    def forward(self, x):
        return self.conv(x)

class BiFPN_layer(nn.Module):
    def __init__(self, first_time, block, network_channel, depth, width):
        super(BiFPN_layer, self).__init__()
        lat_depth, up_depth, down_depth = depth
        self.first_time = first_time

        self.lat_conv = nn.ModuleList()
        self.lat_conv2 = nn.ModuleList()

        self.up_conv = nn.ModuleList()
        self.up_weight = nn.ParameterList()

        self.down_conv = nn.ModuleList()
        self.down_weight = nn.ParameterList()
        self.down_sample = nn.ModuleList()
        self.up_sample = nn.ModuleList()

        for i, channels in enumerate(network_channel):
            if self.first_time:
                self.lat_conv.append(block(channels, channels * width, 1, 1, 0, lat_depth))

            if i != 0:
                self.lat_conv2.append(block(channels, channels * width, 1, 1, 0, lat_depth))
                self.down_conv.append(block(channels * width, channels * width, 3, 1, 1, down_depth))
                num_input = 3 if i < len(network_channel) - 1 else 2

                self.down_weight.append(nn.Parameter(torch.ones(num_input, dtype=torch.float32), requires_grad=True))
                self.down_sample.append(nn.Sequential(MaxPool2dStaticSamePadding(3, 2),
                                                      block(network_channel[i-1] * width, channels * width, 1, 1, 0, 1)))

            if i != len(network_channel) - 1:
                self.up_sample.append(nn.Sequential(nn.Upsample(scale_factor=2, mode='nearest'),
                                                    block(network_channel[i+1] * width, channels * width, 1, 1, 0, 1)))
                self.up_conv.append(block(channels * width, channels * width, 3, 1, 1, up_depth))
                self.up_weight.append(nn.Parameter(torch.ones(2, dtype=torch.float32), requires_grad=True))

        self.relu = nn.ReLU()

        self.epsilon = 1e-6

    def forward(self, inputs, preact=False):
        input_trans = [self.lat_conv2[i - 1](F.relu(inputs[i])) for i in range(1, len(inputs))]
        if self.first_time:
            inputs = [self.lat_conv[i](F.relu(inputs[i])) for i in range(len(inputs))] # for od case

        # up
        up_sample = [inputs[-1]]
        out_layer = []
        for i in range(1, len(inputs)):
            w = self.relu(self.up_weight[-i])
            w = w / (torch.sum(w, dim=0) + self.epsilon)

            up_sample.insert(0,
                             self.up_conv[-i](w[0] * F.relu(inputs[-i - 1])
                                              + w[1] * self.up_sample[-i](F.relu(up_sample[0]))))

        out_layer.append(up_sample[0])

        # down
        for i in range(1, len(inputs)):
            w = self.relu(self.down_weight[i - 1])
            w = w / (torch.sum(w, dim=0) + self.epsilon)
            if i < len(inputs) - 1:
                out_layer.append(self.down_conv[i - 1](w[0] * F.relu(input_trans[i - 1])
                                                       + w[1] * F.relu(up_sample[i])
                                                       + w[2] * self.down_sample[i - 1](F.relu(out_layer[-1]))
                                                       )
                                 )
            else:
                out_layer.append(
                    self.down_conv[i - 1](w[0] * F.relu(input_trans[i - 1])
                                          + w[1] * self.down_sample[i - 1](F.relu(out_layer[-1]))
                                          )
                )

        if not preact:
            return [F.relu(f) for f in out_layer]
        return out_layer

class BiFPNc(nn.Module):
    def __init__(self, network_channel, num_classes, repeat, depth, width, num_features):
        super(BiFPNc, self).__init__()
        repeat = repeat
        depth = depth
        width = width

        self.num_features = num_features
        self.layers = nn.ModuleList()

        self.net_channels = [x * 2 for x in network_channel]
        for i in range(repeat):
            self.layers.append(BiFPN_layer(i == 0, DepthConvBlock, network_channel, depth, width))

        self.Score = nn.Sequential(
            nn.Conv2d(self.net_channels[-1], self.net_channels[-1], kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(self.net_channels[-1]),
            nn.ReLU(inplace=True),
            nn.Dropout2d(p=0.1),
            nn.Conv2d(self.net_channels[-1], 2, kernel_size=1)
        )

    def forward(self, feats, preact=False):
        feats = feats[-self.num_features:]

        for i in range(len(self.layers)):
            layer_preact = preact and i == len(self.layers) - 1
            feats = self.layers[i](feats, layer_preact)

        out = self.Score(feats[-1])
        return feats, out

    def get_bn_before_relu(self):
        layer = self.layers[-1]
        bn = [layer.up_conv[0].conv[-1][-1]]
        for down_conv in layer.down_conv:
            bn.append(down_conv.conv[-1][-1])
        return bn

class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, in_planes, planes, stride=1):
        super(BasicBlock, self).__init__()
        self.conv1 = nn.Conv2d(in_planes, planes, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(planes)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(planes)

        self.shortcut = nn.Sequential()
        if stride != 1 or in_planes != self.expansion*planes:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_planes, self.expansion*planes, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(self.expansion*planes)
            )

    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out += self.shortcut(x)
        out = F.relu(out)
        return out

class Bottleneck(nn.Module):
    def __init__(self, inplanes, planes, stride=1, downsample=None, dilation=1):
        super(Bottleneck, self).__init__()
        self.conv1      = nn.Conv2d(inplanes, planes, kernel_size=1, bias=False)
        self.bn1        = nn.BatchNorm2d(planes)
        self.conv2      = nn.Conv2d(planes, planes, kernel_size=3, stride=stride, padding=(3*dilation-1)//2, bias=False, dilation=dilation)
        self.bn2        = nn.BatchNorm2d(planes)
        self.conv3      = nn.Conv2d(planes, planes*4, kernel_size=1, bias=False)
        self.bn3        = nn.BatchNorm2d(planes*4)
        self.downsample = downsample

    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)), inplace=True)
        out = F.relu(self.bn2(self.conv2(out)), inplace=True)
        out = self.bn3(self.conv3(out))
        if self.downsample is not None:
            x = self.downsample(x)
        return F.relu(out+x, inplace=True)

class ResNet(nn.Module):
    def __init__(self, name, num_blocks, path):
        super(ResNet, self).__init__()
        self.path = path

        if name == 'resnet18':
            self.in_planes = 64
            self.conv1 = nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3, bias=False)
            self.bn1 = nn.BatchNorm2d(64)
            self.layer1 = self._make_layer(BasicBlock, 64, num_blocks[0], stride=1)
            self.layer2 = self._make_layer(BasicBlock, 128, num_blocks[1], stride=2)
            self.layer3 = self._make_layer(BasicBlock, 256, num_blocks[2], stride=2)
            self.layer4 = self._make_layer(BasicBlock, 512, num_blocks[3], stride=2)

        elif name == 'resnet34':
            self.in_planes = 64
            self.conv1 = nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3, bias=False)
            self.bn1 = nn.BatchNorm2d(64)
            self.bn1 = nn.BatchNorm2d(64)
            self.layer1 = self._make_layer(BasicBlock, 64, num_blocks[0], stride=1)
            self.layer2 = self._make_layer(BasicBlock, 128, num_blocks[1], stride=2)
            self.layer3 = self._make_layer(BasicBlock, 256, num_blocks[2], stride=2)
            self.layer4 = self._make_layer(BasicBlock, 512, num_blocks[3], stride=2)


        elif name == 'resnet50':
            self.inplanes = 64
            self.conv1 = nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3, bias=False)
            self.bn1 = nn.BatchNorm2d(64)

            self.layer1 = self.make_layer(64, num_blocks[0], stride=1, dilation=1)
            self.layer2 = self.make_layer(128, num_blocks[1], stride=2, dilation=1)
            self.layer3 = self.make_layer(256, num_blocks[2], stride=2, dilation=1)
            self.layer4 = self.make_layer(512, num_blocks[3], stride=2, dilation=1)


        elif name == 'resnet101':
            self.bkbone = ResNet(Bottleneck, [3, 4, 6, 3])
        elif name == 'resnet152':
            self.bkbone = ResNet(Bottleneck, [3, 8, 36, 3])

    def make_layer(self, planes, blocks, stride, dilation):
        downsample = nn.Sequential(nn.Conv2d(self.inplanes, planes * 4, kernel_size=1, stride=stride, bias=False),
                                   nn.BatchNorm2d(planes * 4))
        layers = [Bottleneck(self.inplanes, planes, stride, downsample, dilation=dilation)]
        self.inplanes = planes * 4
        for _ in range(1, blocks):
            layers.append(Bottleneck(self.inplanes, planes, dilation=dilation))
        return nn.Sequential(*layers)

    def _make_layer(self, block, planes, num_blocks, stride):
        strides = [stride] + [1] * (num_blocks - 1)
        layers = []
        for stride in strides:
            layers.append(block(self.in_planes, planes, stride))
            self.in_planes = planes * block.expansion
        return nn.Sequential(*layers)

    def forward(self, x):
        out1 = F.relu(self.bn1(self.conv1(x)), inplace=True)
        out1 = F.max_pool2d(out1, kernel_size=3, stride=2, padding=1)
        out2 = self.layer1(out1)
        out3 = self.layer2(out2)
        out4 = self.layer3(out3)
        out5 = self.layer4(out4)
        return out2, out3, out4, out5

    def initialize(self):
        self.load_state_dict(torch.load(self.path), strict=False)


class FrskdNet(nn.Module):
    def __init__(self, cfg):
        super(FrskdNet, self).__init__()
        self.cfg      = cfg


        if self.cfg.model_version == 'resnet18':
            self.bkbone = ResNet(self.cfg.model_version, [2, 2, 2, 2], cfg.pretrain)
            self.squeeze = nn.Sequential(nn.Conv2d(960, 16, 1),
                                         nn.BatchNorm2d(16),
                                         nn.ReLU(inplace=True)
                                         )

            self.fullinear = nn.Sequential(
                nn.Conv2d(16, 16, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(16, 2, kernel_size=1)
            )
            infeat_channel = [64, 128, 256, 512]
            num_classes = 2
            repeat = 1
            depth = [2, 2, 2]
            width = 2
            num_features = 4
            self.bifpn = BiFPNc(infeat_channel, num_classes, repeat, depth, width, num_features)
        elif self.cfg.model_version == 'resnet34':
            self.bkbone = ResNet(self.cfg.model_version, [3, 4, 6, 3], cfg.pretrain)
            self.squeeze = nn.Sequential(nn.Conv2d(960, 16, 1),
                                         nn.BatchNorm2d(16),
                                         nn.ReLU(inplace=True)
                                         )

            self.fullinear = nn.Sequential(
                nn.Conv2d(16, 16, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(16, 2, kernel_size=1)
            )
            infeat_channel = [64, 128, 256, 512]
            num_classes = 2
            repeat = 1
            depth = [2, 2, 2]
            width = 2
            num_features = 4
            self.bifpn = BiFPNc(infeat_channel, num_classes, repeat, depth, width, num_features)

        elif self.cfg.model_version == 'resnet50':
            self.bkbone = ResNet(self.cfg.model_version, [3, 4, 6, 3], cfg.pretrain)
            self.squeeze = nn.Sequential(nn.Conv2d(3840, 64, 1),
                                         nn.BatchNorm2d(64),
                                         nn.ReLU(inplace=True)
                                         )

            self.fullinear = nn.Sequential(
                nn.Conv2d(64, 64, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(64, 2, kernel_size=1)
            )

            infeat_channel = [256, 512, 1024, 2048]
            num_classes = 2
            repeat = 1
            depth = [2, 2, 2]
            width = 2
            num_features = 4
            self.bifpn = BiFPNc(infeat_channel, num_classes, repeat, depth, width, num_features)

        elif self.cfg.model_version == 'resnet101':
            self.bkbone = ResNet(Bottleneck, [3, 4, 6, 3])
        elif self.cfg.model_version == 'resnet152':
            self.bkbone = ResNet(Bottleneck, [3, 8, 36, 3])
        self.initialize()

    def forward(self, x, shape=None):
        out2h, out3h, out4h, out5v = self.bkbone(x)

        bkfeat = [out2h, out3h, out4h, out5v]
        bi_feats, bi_outputs = self.bifpn([out2h, out3h, out4h, out5v])

        out3h = F.interpolate(out3h, size=out2h.size()[2:], mode='bilinear')
        out4h = F.interpolate(out4h, size=out2h.size()[2:], mode='bilinear')
        out5v = F.interpolate(out5v, size=out2h.size()[2:], mode='bilinear')
        outfeat = torch.cat([out2h, out3h, out4h, out5v], 1)
        featsqueeze = self.squeeze(outfeat)
        pred = self.fullinear(featsqueeze)

        return pred, bkfeat, bi_feats, bi_outputs

    def initialize(self):
        if self.cfg.snapshot:
            self.load_state_dict(torch.load(self.cfg.snapshot))
        else:
            weight_init(self)


