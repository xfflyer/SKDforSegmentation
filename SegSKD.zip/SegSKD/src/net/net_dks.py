#!/usr/bin/python3
#coding=utf-8

import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import torch.nn.functional as F
from inplace_abn import ABN
BatchNorm2d = ABN
BN_MOMENTUM = 0.01

def weight_init(module):
    for n, m in module.named_children():
        print('initialize: '+n)
        if isinstance(m, nn.Conv2d):
            nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, (nn.BatchNorm2d, nn.InstanceNorm2d)):
            nn.init.ones_(m.weight)
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Linear):
            nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Sequential):
            weight_init(m)
        elif isinstance(m, nn.ReLU):
            pass
        elif isinstance(m, nn.Dropout2d):
            pass
        else:
            m.initialize()


class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, in_planes, planes, stride=1):
        super(BasicBlock, self).__init__()
        self.conv1 = nn.Conv2d(in_planes, planes, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(planes)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(planes)

        self.shortcut = nn.Sequential()
        if stride != 1 or in_planes != self.expansion*planes:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_planes, self.expansion*planes, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(self.expansion*planes)
            )

    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out += self.shortcut(x)
        out = F.relu(out)
        return out


class Bottleneck(nn.Module):
    def __init__(self, inplanes, planes, stride=1, downsample=None, dilation=1):
        super(Bottleneck, self).__init__()
        self.conv1      = nn.Conv2d(inplanes, planes, kernel_size=1, bias=False)
        self.bn1        = nn.BatchNorm2d(planes)
        self.conv2      = nn.Conv2d(planes, planes, kernel_size=3, stride=stride, padding=(3*dilation-1)//2, bias=False, dilation=dilation)
        self.bn2        = nn.BatchNorm2d(planes)
        self.conv3      = nn.Conv2d(planes, planes*4, kernel_size=1, bias=False)
        self.bn3        = nn.BatchNorm2d(planes*4)
        self.downsample = downsample

    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)), inplace=True)
        out = F.relu(self.bn2(self.conv2(out)), inplace=True)
        out = self.bn3(self.conv3(out))
        if self.downsample is not None:
            x = self.downsample(x)
        return F.relu(out+x, inplace=True)

class ResNet(nn.Module):
    def __init__(self, name, num_blocks, path):
        super(ResNet, self).__init__()

        self.path = path

        if name == 'resnet18':
            self.in_planes = 64
            self.conv1 = nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3, bias=False)
            self.bn1 = nn.BatchNorm2d(64)
            self.layer1 = self._make_layer(BasicBlock, 64, num_blocks[0], stride=1)
            inplanes_head2 = self.in_planes
            self.layer2 = self._make_layer(BasicBlock, 128, num_blocks[1], stride=2)
            inplanes_head1 = self.in_planes
            self.layer3 = self._make_layer(BasicBlock, 256, num_blocks[2], stride=2)
            inplanes_head3 = self.in_planes
            self.layer4 = self._make_layer(BasicBlock, 512, num_blocks[3], stride=2)
            self.in_planes = inplanes_head2
            self.layer2_head2 = self._make_layer(BasicBlock, 128, num_blocks[1], stride=1)
            self.layer3_head2 = self._make_layer(BasicBlock, 256, num_blocks[2], stride=1)
            self.layer4_head2 = self._make_layer(BasicBlock, 512, num_blocks[3], stride=1)
            self.in_planes = inplanes_head1
            self.layer3_head1 = self._make_layer(BasicBlock, 256, num_blocks[2], stride=1)
            self.layer4_head1 = self._make_layer(BasicBlock, 512, num_blocks[3], stride=1)
            self.in_planes = inplanes_head3
            self.layer4_head3 = self._make_layer(BasicBlock, 512, num_blocks[3], stride=1)
        elif name == 'resnet34':
            self.in_planes = 64
            self.conv1 = nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3, bias=False)
            self.bn1 = nn.BatchNorm2d(64)
            self.layer1 = self._make_layer(BasicBlock, 64, num_blocks[0], stride=1)
            inplanes_head2 = self.in_planes
            self.layer2 = self._make_layer(BasicBlock, 128, num_blocks[1], stride=2)
            inplanes_head1 = self.in_planes
            self.layer3 = self._make_layer(BasicBlock, 256, num_blocks[2], stride=2)
            inplanes_head3 = self.in_planes
            self.layer4 = self._make_layer(BasicBlock, 512, num_blocks[3], stride=2)

            self.in_planes = inplanes_head2
            self.layer2_head2 = self._make_layer(BasicBlock, 128, num_blocks[1], stride=1)
            self.layer3_head2 = self._make_layer(BasicBlock, 256, num_blocks[2], stride=1)
            self.layer4_head2 = self._make_layer(BasicBlock, 512, num_blocks[3], stride=1)
            self.in_planes = inplanes_head1
            self.layer3_head1 = self._make_layer(BasicBlock, 256, num_blocks[2], stride=1)
            self.layer4_head1 = self._make_layer(BasicBlock, 512, num_blocks[3], stride=1)
            self.in_planes = inplanes_head3
            self.layer4_head3 = self._make_layer(BasicBlock, 512, num_blocks[3], stride=1)

        elif name == 'resnet50':

            self.inplanes = 64
            self.conv1 = nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3, bias=False)
            self.bn1 = nn.BatchNorm2d(64)

            self.layer1 = self.make_layer(64, num_blocks[0], stride=1, dilation=1)
            self.layer2 = self.make_layer(128, num_blocks[1], stride=2, dilation=1)
            inplanes_head2 = self.inplanes
            self.layer3 = self.make_layer(256, num_blocks[2], stride=2, dilation=1)
            inplanes_head3 = self.inplanes
            self.layer4 = self.make_layer(512, num_blocks[3], stride=2, dilation=1)

            self.inplanes = inplanes_head2
            self.layer3_head1 = self.make_layer(256, num_blocks[2], stride=1, dilation=1)
            self.layer4_head1 = self.make_layer(512, int(num_blocks[2] / 2), stride=1, dilation=1)
            self.inplanes = inplanes_head3
            self.layer4_head3 = self.make_layer(1024, num_blocks[3], stride=1, dilation=1)

        elif name == 'resnet101':
            self.bkbone = ResNet(Bottleneck, [3, 4, 6, 3])
        elif name == 'resnet152':
            self.bkbone = ResNet(Bottleneck, [3, 8, 36, 3])



    def make_layer(self, planes, blocks, stride, dilation):
        downsample = nn.Sequential(nn.Conv2d(self.inplanes, planes * 4, kernel_size=1, stride=stride, bias=False),
                                   nn.BatchNorm2d(planes * 4))
        layers = [Bottleneck(self.inplanes, planes, stride, downsample, dilation=dilation)]
        self.inplanes = planes * 4
        for _ in range(1, blocks):
            layers.append(Bottleneck(self.inplanes, planes, dilation=dilation))
        return nn.Sequential(*layers)

    def _make_layer(self, block, planes, num_blocks, stride):
        strides = [stride] + [1] * (num_blocks - 1)
        layers = []
        for stride in strides:
            layers.append(block(self.in_planes, planes, stride))
            self.in_planes = planes * block.expansion
        return nn.Sequential(*layers)


    def forward(self, x):
        x = F.relu(self.bn1(self.conv1(x)), inplace=True)
        x = F.max_pool2d(x, kernel_size=3, stride=2, padding=1)
        x = node2 = self.layer1(x)
        x = node1 = self.layer2(x)
        x = node3 = self.layer3(x)
        x0 = self.layer4(x)

        resfeat = []
        resfeat.append(x0)
        resfeat.append(node3)
        resfeat.append(node1)
        resfeat.append(node2)


        x = self.layer3_head1(node1)
        x1 = self.layer4_head1(x)

        x2 = self.layer4_head3(node3)

        dhmfeat = []
        dhmfeat.append(x1)
        dhmfeat.append(x2)

        return resfeat, dhmfeat

    def initialize(self):
        self.load_state_dict(torch.load(self.path), strict=False)

class DKSNet(nn.Module):
    def __init__(self, cfg):
        super(DKSNet, self).__init__()
        self.cfg      = cfg
        if self.cfg.model_version == 'resnet18':
            self.bkbone = ResNet(self.cfg.model_version, [2, 2, 2, 2], self.cfg.pretrain)
            self.linear1 = nn.Sequential(
                nn.Conv2d(512, 512, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(512),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(512, 2, kernel_size=1)
            )
            self.linear2 = nn.Sequential(
                nn.Conv2d(512, 512, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(512),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(512, 2, kernel_size=1)
            )
            self.linear3 = nn.Sequential(
                nn.Conv2d(512, 512, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(512),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(512, 2, kernel_size=1)
            )
            self.linear4 = nn.Sequential(
                nn.Conv2d(512, 512, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(512),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(512, 2, kernel_size=1)
            )
            self.squeeze = nn.Sequential(nn.Conv2d(960, 16, 1),
                                         nn.BatchNorm2d(16),
                                         nn.ReLU(inplace=True)
                                         )
            self.fullinear = nn.Sequential(
                nn.Conv2d(16, 16, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(16, 2, kernel_size=1)
            )
        elif self.cfg.model_version == 'resnet34':
            self.bkbone = ResNet(self.cfg.model_version, [3, 4, 6, 3], self.cfg.pretrain)
            self.linear1 = nn.Sequential(
                nn.Conv2d(512, 512, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(512),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(512, 2, kernel_size=1)
            )
            self.linear2 = nn.Sequential(
                nn.Conv2d(512, 512, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(512),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(512, 2, kernel_size=1)
            )
            self.linear3 = nn.Sequential(
                nn.Conv2d(512, 512, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(512),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(512, 2, kernel_size=1)
            )
            self.linear4 = nn.Sequential(
                nn.Conv2d(512, 512, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(512),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(512, 2, kernel_size=1)
            )
            self.squeeze = nn.Sequential(nn.Conv2d(960, 16, 1),
                                         nn.BatchNorm2d(16),
                                         nn.ReLU(inplace=True)
                                         )
            self.fullinear = nn.Sequential(
                nn.Conv2d(16, 16, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(16, 2, kernel_size=1)
            )

        elif self.cfg.model_version == 'resnet50':

            self.bkbone = ResNet(self.cfg.model_version, [3, 4, 6, 3], self.cfg.pretrain)

            self.linear1 = nn.Sequential(
                nn.Conv2d(2048, 2048, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(2048),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(2048, 2, kernel_size=1)
            )
            self.linear2 = nn.Sequential(
                nn.Conv2d(2048, 2048, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(2048),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(2048, 2, kernel_size=1)
            )
            self.linear3 = nn.Sequential(
                nn.Conv2d(4096, 4096, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(4096),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(4096, 2, kernel_size=1)
            )


            self.squeeze = nn.Sequential(nn.Conv2d(3840, 64, 1),
                                         nn.BatchNorm2d(64),
                                         nn.ReLU(inplace=True)
                                         )

            self.fullinear = nn.Sequential(
                nn.Conv2d(64, 64, kernel_size=3, padding=1, bias=False),
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True),
                nn.Dropout2d(p=0.1),
                nn.Conv2d(64, 2, kernel_size=1)
            )

        elif self.cfg.model_version == 'resnet101':
            self.bkbone = ResNet(Bottleneck, [3, 4, 6, 3])
        elif self.cfg.model_version == 'resnet152':
            self.bkbone = ResNet(Bottleneck, [3, 8, 36, 3])



        self.initialize()

    def forward(self, x, shape=None):
        resfeat, backfeat = self.bkbone(x)

        featscore = []
        featscore.append(self.linear1(resfeat[0]))
        featscore.append(self.linear2(backfeat[0]))
        featscore.append(self.linear3(backfeat[1]))

        head1 = F.interpolate(resfeat[0], size=resfeat[3].size()[2:], mode='bilinear')
        head2 = F.interpolate(resfeat[1], size=resfeat[3].size()[2:], mode='bilinear')
        head3 = F.interpolate(resfeat[2], size=resfeat[3].size()[2:], mode='bilinear')
        outfeat = torch.cat([head1, head2, head3, resfeat[3]], 1)
        featsqueeze = self.squeeze(outfeat)
        pred = self.fullinear(featsqueeze)


        return pred, featscore


    def initialize(self):
        if self.cfg.snapshot:
            # pretrained_dict = torch.load(self.cfg.snapshot)
            # model_dict = self.state_dict()
            # pretrained_dict = {k[6:]: v for k, v in pretrained_dict.items()
            #                    if k[6:] in model_dict.keys()}
            # model_dict.update(pretrained_dict)
            # self.load_state_dict(model_dict)
            self.load_state_dict(torch.load(self.cfg.snapshot))
        else:
            weight_init(self)
