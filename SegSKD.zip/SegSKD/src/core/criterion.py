# ------------------------------------------------------------------------------
# Copyright (c) Microsoft
# Licensed under the MIT License.
# Written by Ke Sun (sunk@mail.ustc.edu.cn)
# ------------------------------------------------------------------------------

import torch
import torch.nn as nn
from torch.nn import functional as F
import numpy as np
import cv2


class CrossEntropy(nn.Module):
    def __init__(self, ignore_label=-1, weight=None):
        super(CrossEntropy, self).__init__()
        self.ignore_label = ignore_label
        self.criterion = nn.CrossEntropyLoss(weight=weight,
                                             ignore_index=ignore_label)

    def forward(self, score, target):
        ph, pw = score.size(2), score.size(3)
        h, w = target.size(-2), target.size(-1)
        if ph != h or pw != w:
            score = F.upsample(
                    input=score, size=(h, w), mode='bilinear')
        target = target.long().cuda()
        loss = self.criterion(score, target.squeeze(dim=1))

        return loss




class KLDivLoss(nn.Module):
    def __init__(self, ignore_index=255, T1 = 1,  T2 = 1, reduce=True):
        super(KLDivLoss, self).__init__()
        self.ignore_index = ignore_index
        self.T1 = T1
        self.T2 = T2
    def forward(self, logits_p, logits_q):

        assert logits_p.size() == logits_q.size()
        N, C, W, H = logits_p.shape
        # b, c = logits_p.size()
        T1 = self.T1
        T2 = self.T2
        logits_p = logits_p/T1
        logits_q = logits_q/T2
        p = F.softmax(logits_p.permute(0, 2, 3, 1).contiguous().view(-1, C), dim=1)
        q = F.softmax(logits_q.permute(0, 2, 3, 1).contiguous().view(-1, C), dim=1)

        b, c = p.size()
        epsilon = 1e-8
        _p = (p + epsilon * torch.ones(b, c).cuda()) / (1.0 + c * epsilon)
        _q = (q + epsilon * torch.ones(b, c).cuda()) / (1.0 + c * epsilon)
        loss = (1 ** 2) * torch.mean(torch.sum(_p * torch.log(_p / _q), dim=1))
        return loss

class MMDLoss(nn.Module):
    """Distillation Loss"""

    def __init__(self):
        super().__init__()

        self.MMD = nn.MSELoss(reduction="none")
    def forward(self, tea_features, stu_features):
        N, C, W, H = tea_features.shape
        p = tea_features.permute(0, 2, 3, 1).contiguous().view(-1, C)
        q = stu_features.permute(0, 2, 3, 1).contiguous().view(-1, C)
        mse = self.MMD(p,q)
        mseloss = torch.mean(mse, dim=1).mean()
        return mseloss

class SCALoss(nn.Module):
    """Distillation Loss"""

    def __init__(self):
        super().__init__()

    def forward(self, tea_features, stu_features):
        # loss = 0.

        # tea_features1 = tea_features.mean(dim=(2, 3), keepdim=False)
        # stu_features1 = stu_features.mean(dim=(2, 3), keepdim=False)
        # closs = torch.mean(torch.pow(tea_features1 - stu_features1, 2))

        tea_features2 = tea_features.mean(dim = 1, keepdim=False)
        stu_features2 = stu_features.mean(dim = 1, keepdim=False)
        sloss = torch.mean(torch.pow(tea_features2 - stu_features2, 2))
        loss = sloss
        return loss

class SFLoss(nn.Module):

    def __init__(self):
        super().__init__()

    def forward(self, tea_features, stu_features):

        loss = torch.mean(torch.pow(tea_features - stu_features, 2))

        return loss

class SALoss(nn.Module):

    def __init__(self):
        super().__init__()

    def forward(self, tea_features, stu_features, size):

        tea_features2 = tea_features.mean(dim=1, keepdim=True)
        stu_features2 = stu_features.mean(dim=1, keepdim=True)
        tea_features2 = F.interpolate(tea_features2, size=size, mode='bilinear')
        stu_features2 = F.interpolate(stu_features2, size=size, mode='bilinear')
        loss = torch.mean(torch.pow(tea_features2 - stu_features2, 2))

        return loss

def KLdis(p, q):
    b, c = p.size()
    epsilon = 1e-8
    _p = (p + epsilon * torch.ones(b, c).cuda()) / (1.0 + c * epsilon)
    _q = (q + epsilon * torch.ones(b, c).cuda()) / (1.0 + c * epsilon)
    loss = (1 ** 2) * torch.mean(torch.sum(_p * torch.log(_p / _q), dim=1))
    return loss

class CSKLDivLoss(nn.Module):
    def __init__(self, ignore_index=255, T1 = 1,  T2 = 1, reduce=True):
        super(CSKLDivLoss, self).__init__()
        self.ignore_index = ignore_index
        self.T1 = T1
        self.T2 = T2

    def forward(self, logits_p, logits_q, mask1, mask2):
        assert logits_p.size() == logits_q.size()
        N, C, W, H = logits_p.shape

        T1 = self.T1
        T2 = self.T2
        logits_p = logits_p/T1
        logits_q = logits_q/T2
        p = F.softmax(logits_p.permute(0, 2, 3, 1).contiguous().view(-1, C), dim=1)
        q = F.softmax(logits_q.permute(0, 2, 3, 1).contiguous().view(-1, C), dim=1)

        b, c = p.size()
        epsilon = 1e-8
        _p = (p + epsilon * torch.ones(b, c).cuda()) / (1.0 + c * epsilon)
        _q = (q + epsilon * torch.ones(b, c).cuda()) / (1.0 + c * epsilon)
        loss = (1 ** 2) * torch.mean(torch.sum(_p * torch.log(_p / _q), dim=1))

        # maskindex1 = mask1.permute(0, 2, 3, 1).contiguous().view(-1, 1).detach().cpu().numpy()
        # m1_index1 = np.where(maskindex1 == 1)
        # m1_num1 = len(m1_index1[0])
        # m1_index0 = np.where(maskindex1 == 0)
        # m1_num0 = len(m1_index0[0])
        #
        # maskindex2 = mask2.permute(0, 2, 3, 1).contiguous().view(-1, 1).detach().cpu().numpy()
        # m2_index1 = np.where(maskindex2 == 1)
        # m2_num1 = len(m2_index1[0])
        # m2_index0 = np.where(maskindex2 == 0)
        # m2_num0 = len(m2_index0[0])
        # if (m1_num1 > 0)&(m2_num1>0):
        #     if m1_num1 > m2_num1:
        #         sel_num1 = m2_num1
        #     else:
        #         sel_num1 = m1_num1
        #
        #     selindex2 = m2_index1[0][:sel_num1]
        #     sel_q = q[selindex2, :]
        #     selindex1 = m1_index1[0][:sel_num1]
        #     sel_p = p[selindex1, :]
        #     loss1 = KLdis(sel_p, sel_q)
        # else:
        #     loss1 = 0
        #
        # if (m1_num0 > 0) & (m2_num0 > 0):
        #     if m1_num0 > m2_num0:
        #         sel_num0 = m2_num0
        #     else:
        #         sel_num0 = m1_num0
        #
        #     selindex2 = m2_index0[0][:sel_num0]
        #     sel_q = q[selindex2, :]
        #     selindex1 = m1_index0[0][:sel_num0]
        #     sel_p = p[selindex1, :]
        #     loss2 =  KLdis(sel_p, sel_q)
        # else:
        #     loss2 = 0
        # loss = (loss1 + loss2)/2
        return loss



