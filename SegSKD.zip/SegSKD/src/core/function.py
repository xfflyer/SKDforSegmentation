# ------------------------------------------------------------------------------
# Copyright (c) Microsoft
# Licensed under the MIT License.
# Written by Ke Sun (sunk@mail.ustc.edu.cn)
# ------------------------------------------------------------------------------

import logging
import os
import time

import numpy as np
import numpy.ma as ma
from tqdm import tqdm

import torch
import torch.nn as nn
from torch.nn import functional as F


from utils.utils import AverageMeter
from utils.utils import get_confusion_matrix
from utils.utils import adjust_learning_rate

def mae(preds, labels):
    dimnum = len(preds.shape)
    mae = []
    if dimnum == 4:
        for i in range(preds.shape[0]):
            pred = np.squeeze(preds[i, :, :, :])
            pred = (pred - pred.min()) / (pred.max() - pred.min())
            label = np.squeeze(labels[i, :, :, :])
            mae.append(np.mean(np.abs(preds - labels))/preds.shape[0])
    mean_mae = np.mean(mae)
    return mean_mae

def fscore(preds, labels, th=0.5):
    dimnum = len(preds.shape)
    F = []
    if dimnum == 4:
        for i in range(preds.shape[0]):
            pred = np.squeeze(preds[i, :, :, :])
            pred = (pred - pred.min()) / (pred.max() - pred.min())
            label = np.squeeze(labels[i, :, :, :])
            ogt = (label == 1)
            bgt = (label == 0)
            tmp1 = pred[ogt] >= th
            TP = np.sum(tmp1)
            tmp2 = pred[bgt] >= th
            FP = np.sum(tmp2)
            tmp3 = pred[ogt] < th
            FN = np.sum(tmp3)
            precision = TP / (TP + FP)
            recall = TP / (TP + FN)
            F.append((1.3 * precision * recall) / (recall + 0.3 * precision + 1e-9))
    mf = np.mean(F)
    return mf

def train(config, epoch, num_epoch, epoch_iters, base_lr,
        num_iters, trainloader, optimizer, model, writer_dict):
    # Training
    model.train()
    batch_time = AverageMeter()
    ave_loss1 = AverageMeter()
    ave_loss2 = AverageMeter()
    ave_loss3 = AverageMeter()
    ave_loss4 = AverageMeter()
    ave_loss5 = AverageMeter()
    ave_loss6 = AverageMeter()
    ave_loss7 = AverageMeter()
    ave_loss8 = AverageMeter()
    ave_loss9 = AverageMeter()
    ave_loss10 = AverageMeter()
    ave_loss11 = AverageMeter()
    ave_loss = AverageMeter()
    tic = time.time()
    cur_iters = epoch*epoch_iters
    writer = writer_dict['writer']
    global_steps = writer_dict['train_global_steps']

    # final_output_dir = '/data/Result/HRS/Models/CAM/distill_r288_b8_hr48_0.1cst+0.1u2b_bce_kl/distill_r288_b8_hr48_0.1cst+0.1u2b_bce_kl/Expconvergence/'
    for i_iter, batch in enumerate(trainloader, 0):
        images, label0, label1, label2, label3, label4, _, name = batch

        label0 = label0.cuda()
        label1 = label1.cuda()
        label2 = label2.cuda()
        label3 = label3.cuda()
        label4 = label4.cuda()

        # bloss, closs, u2bdis_loss, b2udis_loss, ms4loss, pred, emau_u2bdis_loss, emau_ms4loss, emau_cst_loss, pspemau_cst_loss = model(images, label0, label1, label2, label3, label4)
        bloss, closs, u2bdis_loss, b2udis_loss, ms4loss = model(images, label0, label1, label2, label3, label4)

        size = label0.size()
        bloss = bloss.mean()

        if closs[0].size(0) > 1:
            distillbuf1 = []
            for cc in range(0, len(closs)):
                distillbuf1.append(closs[cc].mean())

        if u2bdis_loss[0].size(0) > 1:
            distillbuf2 = []
            for cc in range(0, len(u2bdis_loss)):
                distillbuf2.append(u2bdis_loss[cc].mean())

        if ms4loss[0].size(0) > 1:
            distillbuf3 = []
            for cc in range(0, len(ms4loss)):
                distillbuf3.append(ms4loss[cc].mean())

        if b2udis_loss[0].size(0) > 1:
            distillbuf4 = []
            for cc in range(0, len(b2udis_loss)):
                distillbuf4.append(b2udis_loss[cc].mean())

        # if emau_ms4loss[0].size(0) > 1:
        #     distillbuf5 = []
        #     for cc in range(0, len(emau_ms4loss)):
        #         distillbuf5.append(emau_ms4loss[cc].mean())
        #
        # if emau_u2bdis_loss[0].size(0) > 1:
        #     distillbuf6 = []
        #     for cc in range(0, len(emau_u2bdis_loss)):
        #         distillbuf6.append(emau_u2bdis_loss[cc].mean())
        #
        # if emau_cst_loss[0].size(0) > 1:
        #     distillbuf7 = []
        #     for cc in range(0, len(emau_cst_loss)):
        #         distillbuf7.append(emau_cst_loss[cc].mean())
        #
        # if pspemau_cst_loss[0].size(0) > 1:
        #     distillbuf8 = []
        #     for cc in range(0, len(pspemau_cst_loss)):
        #         distillbuf8.append(pspemau_cst_loss[cc].mean())

        cst_closs = sum(distillbuf1)/len(distillbuf1)
        u2b_closs = sum(distillbuf2) / len(distillbuf2)
        seg0_loss = distillbuf3[-1]
        seg1_loss = sum(distillbuf3[0:-1]) / len(distillbuf3[0:-1])
        b2u_closs = sum(distillbuf4) / len(distillbuf4)

        # ema_u2b_closs = sum(distillbuf6) / len(distillbuf6)
        # ema_seg0_loss = distillbuf5[-1]
        # ema_seg1_loss = sum(distillbuf5[0:-1]) / len(distillbuf5[0:-1])
        # ema_cst_closs = sum(distillbuf7) / len(distillbuf7)
        # pspema_cst_closs = sum(distillbuf8) / len(distillbuf8)

        ##0.7109(b8,hr48,r320),0.7037,0.7029(b8,hr48,r288),0.7007(b12,hr48,r288)/Cam;
        # 0.6393(b12,hr18,r288),0.6394(b10,hr18,r288)/Cam;
        ##0.7592(48,320),0.7413(48,288),0.6810(18,288)/Cam2;
        ## 0.7339(320),0.7249(48,288),0.6486(18,b10,288),0.6304(18,b10,288)/camp;
        ## 0.8418(48,320)0.8503(48,320),0.8440(b12,hr48,288),0.8459/0.8455(b8,hr48,288),0.8446/0.8486/0.8499(e20/e25/e30,b8,hr48,288), 0.8136(18,288)/DUT-OMROM;
        ##0.8850/0.8756/0.8755(e30/e25/e30,b8,hr48,288)//DUTS-TE;
        ##0.8524/0.8575/0.8618(e30/e25/e20,b12,hr18,288)//DUTS-TE;
        ## 0.8514(48,320),0.8430(48,288),0.8449(b8,hr48,r288)0.8596(b8,hr48,r288),0.8233(BATCH10,18,288),0.8376(batch12,18,288),0.8305(batch14,18,288)/PASCAL-S
        # loss = bloss


        # loss = bloss + (b2u_closs+seg1_loss)

        # loss = bloss + cst_closs + u2b_closs + seg1_loss ##0.6988
        # loss = bloss + cst_closs + u2b_closs + 2*seg1_loss ##0.7003,LR: 0.01;0.6983,LR: 0.02;
        # loss = bloss + 0.5*(cst_closs + u2b_closs) + seg1_loss ##0.6977
        # loss = bloss + cst_closs + u2b_closs + 4seg1_loss + seg0_loss ##0.7043/subtrain,0.7247/train,
        # loss = bloss + 5*(cst_closs + u2b_closs) + seg1_loss + seg0_loss ##0.6924/subtrain
        # loss = bloss + cst_closs + u2b_closs + seg1_loss + seg0_loss + b2u_closs + seg1_loss##0.7023/subtrain
        # loss = bloss + cst_closs + u2b_closs + seg1_loss + seg0_loss + b2u_closs + seg0_loss ##0.7013/subtrain
        # loss = bloss + cst_closs + u2b_closs + seg1_loss + seg0_loss + b2u_closs ##0.6985/subtrain,0.8595/PASCAL-S
        # loss = bloss + cst_closs + b2u_closs + seg1_loss + seg0_loss ##0.6959/subtrain
        # loss = bloss + cst_closs + seg1_loss + seg0_loss ##0.7246/train
        # loss = bloss + 0.msloss41*cst_closs + seg1_loss + seg0_loss  ##0.7263/train
        # loss = bloss + 0.1*u2b_closs + seg1_loss + seg0_loss  ##0.7263/train
        # loss = bloss + 0.01 * u2b_closs + seg1_loss + seg0_loss  ##0.7248/train


        ##0.7267(b8,hr48,r320),0.7112(b8,hr48,r288),0.7019(b12,hr48,r288),0.7152(b8,hr48,r288,0.2ssim+0.8bce_0.8kl+0.2ssim)/Cam
        # 0.6430(b12,hr18,r288),0.6479、0.6483、0.6454、0.6466(b10,hr18,r288)/Cam
        # 0.6509(b10,hr18,r288,ssim+bce_kd+kl),0.6512(b10,hr18,r288,0.5ssim+0.5bce_0.5kl+0.5ssim)/Cam
        # 0.6519(b10,hr18,r288,ssim+bce_0.8kl+0.2ssim),0.6531(b10,hr18,r288,0.2ssim+0.8bce_0.8kl+0.2ssim)/Cam
        # 0.6482(b10,hr18,r288,0.1ssim+0.9bce_0.8kl+0.2ssim),0.6451(b10,hr18,r288,0.8ssim+0.2bce_0.8kl+0.2ssim)/Cam,



        ##0.7687(320);0.7571(48,288),0.6939(18,288)/Cam2;
        ##0.7369,0.7314,0.7275(b12,hr48,r288,0.2ssim+0.8bce_0.8kl+0.2ssim)/Camp;
        # 0.7275,0.6377(b12,hr18,r288,0.2ssim+0.8bce_0.8kl+0.2ssim),0.6471(b10,hr18,r288,0.8ssim+0.2bce_0.8kl+0.2ssim)/Camp;
        ### 0.8499(48,320),0.8536(320),0.8532(288),0.854
        # 0.8575/0.8586/0.8555(e20/e25/e30, b8,hr48,r288,0.2ssim+0.8bce_0.8kl+0.2ssim)/DUT-OMROM;
        ## 0.8501(b12,hr48,r288,0.2ssim+0.8bce_0.8kl+0.2ssim),0.8261(b10,hr18,r288,0.2ssim+0.8bce_0.8kl+0.2ssim)/DUT-OMROM;
        ###0.8897/0.8960/0.8898(e30/e25/e20, b8,hr48,r288,0.2ssim+0.8bce_0.8kl+0.2ssim)/DUTS-TE
        ###0.8588/0.8578/0.8639(e30/e25/e20, b12,hr18,r288,0.2ssim+0.8bce_0.8kl+0.2ssim)/DUTS-TE
        ##0.8600(48,320),0.8569(48,288),0.8747/0.8728/0.8701(e20/e25/e30,b8,hr48,r288,0.8ssim+0.2bce_0.8kl+0.2ssim),0.8371(batch10,18,288),0.8418(batch12,18,288),0.8327(batch14,18,288)/PASCAL-S
        # loss = bloss + 0.1 * cst_closs + 0.1 * u2b_closs + seg1_loss + seg0_loss + 0.1*ema_cst_closs + ema_seg1_loss + 0.1*ema_u2b_closs + ema_seg0_loss + 0.01*pspema_cst_closs
        loss = bloss + 0.1 * cst_closs + 0.1 * u2b_closs + seg1_loss + seg0_loss

        #消融实验
        # loss = bloss + seg1_loss + seg0_loss###CE
        # loss = bloss + 0.1 * cst_closs + seg1_loss
        # loss = bloss + 0.1 * u2b_closs + seg0_loss
        # loss = bloss + 0.1 * u2b_closs + 0.1 * cst_closs

        # 0.8403/0.8487(e20, b8,hr48,r288,0.2ssim+0.8bce_0.8kl+0.2ssim)/PASCAL-S
        # loss = bloss + 0.1 * cst_closs + 0.1 * u2b_closs + 0.1 * b2u_closs + seg1_loss + seg0_loss


        # loss = bloss + 0.05 * cst_closs + seg1_loss + seg0_loss  ##0.7253/train
        # loss = bloss + 0.1*b2u_closs + seg1_loss + seg0_loss  ##0.7234/train

        ##0.7022(b8,hr48,r288,no pspmodule)/train
        ##0.8502(b8,hr48,r288,no pspmodule)/train,DUT-OMROM
        ##0.8486(b8,hr48,r288,no pspmodule)/train,PASCAL-S
        ##0.8527(b8,hr48,r288,pspmodule)/train,PASCAL-S
        ##0.8324(r288,b12,hr18,0.2ssim+0.8bce_0.8kl+0.2ssim)/train,PASCAL-S
        # loss = bloss + u2b_closs + seg0_loss
        ##0.8666(b8,hr48,r288,pspmodule),0.8319(b10,hr18,r288,0.8ssim+0.2bce_0.8kl+0.2ssim)/train,PASCAL-S
        ##0.6578(b10,hr18,r288,0.2ssim+0.8bce_0.8kl+0.2ssim)/train,CAMP
        # loss = bloss + 0.1*u2b_closs + seg0_loss
        ##0.8596(b8,hr48,r288,pspmodule)/train,PASCAL-S
        # loss = bloss + seg0_loss
        ##0.8587(b8,hr48,r288,pspmodule)/train,PASCAL-S
        # loss = bloss + seg1_loss
        ##0.8517(b8,hr48,r288,pspmodule)/train,PASCAL-S
        # loss = bloss + u2b_closs
        #0.8561(b8,hr48,r288,pspmodule)/train,PASCAL-S
        # loss = bloss + 0.1*u2b_closs
        ##0.8602(b8,hr48,r288,pspmodule)/train,PASCAL-S
        # loss = bloss + cst_closs
        ##0.8591(b8,hr48,r288,pspmodule)/train,PASCAL-S
        # loss = bloss + cst_closs + seg1_loss

        ##0.8600(b8,hr48,r288,pspmodule)/train,PASCAL-S
        ##0.7341(b8,hr48,r288,0.2ssim+0.8bce_0.8kl+0.2ssim),0.6535(b10,hr18,r288,0.2ssim+0.8bce_0.8kl+0.2ssim)/train,camp
        # loss = bloss + 0.1*cst_closs + seg1_loss
        # # 0.8546(b8,hr48,r288,pspmodule)/train,PASCAL-S
        # loss = bloss + 0.1*cst_closs + seg1_loss + 0.1*u2b_closs + seg0_loss
        # 0.8559(b8,hr48,r288,pspmodule)/train,PASCAL-S
        # loss = bloss + 0.5*(0.1*cst_closs + seg1_loss) + 0.5*(0.1*u2b_closs + seg0_loss)
        # 0.8550(b8,hr48,r288,pspmodule)/train,PASCAL-S
        # loss = bloss + (0.1*cst_closs + seg1_loss) + 2*(0.1*u2b_closs + seg0_loss)

        # 0.8646(b8,hr48,r288,pspmodule,bce_kl)/train,PASCAL-S
        # 0.8636(b8,hr48,r288,pspmodule,bce_0.8kl+0.2ssim)/train,PASCAL-S
        # loss = bloss + 2*(0.1*cst_closs + seg1_loss) + (0.1*u2b_closs + seg0_loss)
        # 0.8597(b8,hr48,r288,pspmodule)/train,PASCAL-S
        # loss = bloss + 3*(0.1*cst_closs + seg1_loss) + (0.1*u2b_closs + seg0_loss)
        # 0.8643(b8,hr48,r288,pspmodule,bce_kl)/train,PASCAL-S
        # loss = bloss + 2*(0.1*cst_closs + seg1_loss) + 0.8*(0.1*u2b_closs + seg0_loss)

        # loss = bloss + u2b_closs ##0.7055(b8,hr48,r288,no pspmodule)/train


        model.zero_grad()
        loss.backward()
        optimizer.step()

        # measure elapsed time
        batch_time.update(time.time() - tic)
        tic = time.time()

        # update 一致性 average loss
        ave_loss1.update(bloss.item())
        ave_loss2.update(u2b_closs.item())
        ave_loss3.update(seg0_loss.item())
        ave_loss4.update(cst_closs.item())
        ave_loss5.update(seg1_loss.item())
        ave_loss6.update(b2u_closs.item())
        ave_loss.update(loss.item())


        lr = adjust_learning_rate(optimizer,
                                  base_lr,
                                  num_iters,
                                  i_iter+cur_iters)

        if i_iter % config.PRINT_FREQ == 0:
            msg = 'Epoch: [{}/{}] Iter:[{}/{}], Time: {:.2f}, lr: {:.6f}, ' \
                  'Loss: {:.4f},' \
                  'head_loss: {:.5f}, u2b_loss: {:.5f},' \
                  'seg0_loss: {:.5f}, cst_loss: {:.5f}, ' \
                  'seg1_loss: {:.5f}, b2u_loss: {:.5f}' .format(
                      epoch, num_epoch, i_iter, epoch_iters, batch_time.average(), lr,
                      ave_loss.average(),
                      ave_loss1.average(),
                      ave_loss2.average(),
                      ave_loss3.average(),
                      ave_loss4.average(),
                      ave_loss5.average(),
                      ave_loss6.average(),
            )
            logging.info(msg)
        # if (i_iter + 1) % 10 == 0:
        #     modelname = "mbatch_%d.pth" % (8*(i_iter + 1))
        #     torch.save(model.module.state_dict(),
        #                os.path.join(final_output_dir, modelname))

    writer.add_scalar('train_loss', ave_loss.average(), global_steps)
    writer.add_scalar('train_head_loss', ave_loss1.average(), global_steps)
    writer.add_scalar('train_u2b_loss', ave_loss2.average(), global_steps)
    writer.add_scalar('train_seg0_loss', ave_loss3.average(), global_steps)
    writer.add_scalar('train_cst_loss', ave_loss4.average(), global_steps)
    writer.add_scalar('train_seg1_loss', ave_loss5.average(), global_steps)
    writer.add_scalar('train_b2u_loss', ave_loss6.average(), global_steps)
    writer_dict['train_global_steps'] = global_steps + 1

    alloss = []
    alloss.append(ave_loss.average())
    alloss.append(ave_loss1.average())
    alloss.append(ave_loss2.average())
    alloss.append(ave_loss3.average())
    alloss.append(ave_loss4.average())
    alloss.append(ave_loss5.average())
    alloss.append(ave_loss6.average())
    return alloss

def validate(config, testloader, model, writer_dict):
    model.eval()
    ave_loss = AverageMeter()
    ave_loss1 = AverageMeter()
    ave_loss2 = AverageMeter()
    ave_loss3 = AverageMeter()
    ave_loss4 = AverageMeter()
    ave_loss5 = AverageMeter()
    ave_loss6 = AverageMeter()
    with torch.no_grad():
        for _, batch in enumerate(testloader):

            images, label0, label1, label2, label3, label4, _, _ = batch
            size = label0.size()
            label0 = label0.cuda()
            label1 = label1.cuda()
            label2 = label2.cuda()
            label3 = label3.cuda()
            label4 = label4.cuda()

            bloss, closs, u2bdis_loss, b2udis_loss, ms4loss, pred = model(images, label0, label1, label2, label3, label4)
            size = label0.size()
            bloss = bloss.mean()

            if closs[0].size(0) > 1:
                distillbuf1 = []
                for cc in range(0, len(closs)):
                    distillbuf1.append(closs[cc].mean())

            if u2bdis_loss[0].size(0) > 1:
                distillbuf2 = []
                for cc in range(0, len(u2bdis_loss)):
                    distillbuf2.append(u2bdis_loss[cc].mean())

            if ms4loss[0].size(0) > 1:
                distillbuf3 = []
                for cc in range(0, len(ms4loss)):
                    distillbuf3.append(ms4loss[cc].mean())

            if b2udis_loss[0].size(0) > 1:
                distillbuf4 = []
                for cc in range(0, len(b2udis_loss)):
                    distillbuf4.append(b2udis_loss[cc].mean())

            cst_closs = sum(distillbuf1) / len(distillbuf1)
            u2b_closs = sum(distillbuf2) / len(distillbuf2)
            seg0_loss = distillbuf3[-1]
            seg1_loss = sum(distillbuf3[0:-1]) / len(distillbuf3[0:-1])
            b2u_closs = sum(distillbuf4) / len(distillbuf4)

            loss = bloss

            # loss = bloss + (b2u_closs+seg1_loss)
            # loss = bloss + cst_closs+ u2b_closs + seg1_loss
            # loss = bloss + cst_closs + u2b_closs + 2*seg1_loss
            # loss = bloss + 0.5 * (cst_closs + u2b_closs) + seg1_loss
            # loss = bloss + cst_closs + u2b_closs + seg1_loss + seg0_loss
            # loss = bloss + 5 * (cst_closs + u2b_closs) + seg1_loss + seg0_loss
            # loss = bloss + cst_closs + u2b_closs + seg1_loss + seg0_loss + b2u_closs + seg1_loss
            # loss = bloss + cst_closs + u2b_closs + seg1_loss + seg0_loss + b2u_closs + seg0_loss
            # loss = bloss + cst_closs + b2u_closs + seg1_loss + seg0_loss
            # loss = bloss + cst_closs + seg1_loss + seg0_loss
            # loss = bloss + 0.1 * cst_closs + seg1_loss + seg0_loss
            # loss = bloss + 0.05 * cst_closs + seg1_loss + seg0_loss
            # loss = bloss + 0.1 * b2u_closs + seg1_loss + seg0_loss
            # loss = bloss + 0.01 * u2b_closs + seg1_loss + seg0_loss
            # loss = bloss + 0.1 * cst_closs + 0.1 * u2b_closs + seg1_loss + seg0_loss

            # update 一致性 average loss
            ave_loss1.update(bloss.item())
            ave_loss2.update(u2b_closs.item())
            ave_loss3.update(seg0_loss.item())
            ave_loss4.update(cst_closs.item())
            ave_loss5.update(seg1_loss.item())
            ave_loss6.update(b2u_closs.item())
            ave_loss.update(loss.item())



    writer = writer_dict['writer']
    global_steps = writer_dict['valid_global_steps']
    writer.add_scalar('valid_loss', ave_loss.average(), global_steps)
    writer.add_scalar('valid_head_loss', ave_loss1.average(), global_steps)
    writer.add_scalar('valid_u2b_loss', ave_loss2.average(), global_steps)
    writer.add_scalar('valid_seg0_loss', ave_loss3.average(), global_steps)
    writer.add_scalar('valid_cst_loss', ave_loss4.average(), global_steps)
    writer.add_scalar('valid_seg1_loss', ave_loss5.average(), global_steps)
    writer.add_scalar('valid_b2u_loss', ave_loss6.average(), global_steps)
    writer_dict['valid_global_steps'] = global_steps + 1

    alloss = []
    alloss.append(ave_loss.average())
    alloss.append(ave_loss1.average())
    alloss.append(ave_loss2.average())
    alloss.append(ave_loss3.average())
    alloss.append(ave_loss4.average())
    alloss.append(ave_loss5.average())
    alloss.append(ave_loss6.average())
    return alloss

def testval(config, test_dataset, testloader, model, 
        sv_dir='', sv_pred=False):
    model.eval()
    confusion_matrix = np.zeros(
        (config.DATASET.NUM_CLASSES, config.DATASET.NUM_CLASSES))
    with torch.no_grad():
        for index, batch in enumerate(tqdm(testloader)):
            image, label, _, name = batch
            size = label.size()
            pred = test_dataset.multi_scale_inference(
                        model, 
                        image, 
                        scales=config.TEST.SCALE_LIST, 
                        flip=config.TEST.FLIP_TEST)
            
            if pred.size()[-2] != size[-2] or pred.size()[-1] != size[-1]:
                pred = F.upsample(pred, (size[-2], size[-1]), 
                                   mode='bilinear')

            confusion_matrix += get_confusion_matrix(
                label,
                pred,
                size,
                config.DATASET.NUM_CLASSES,
                config.TRAIN.IGNORE_LABEL)

            if sv_pred:
                sv_path = os.path.join(sv_dir,'test_results')
                if not os.path.exists(sv_path):
                    os.mkdir(sv_path)
                test_dataset.save_pred(pred, sv_path, name)
            preds
            if index % 100 == 0:
                logging.info('processing: %d images' % index)
                pos = confusion_matrix.sum(1)
                res = confusion_matrix.sum(0)
                tp = np.diag(confusion_matrix)
                IoU_array = (tp / np.maximum(1.0, pos + res - tp))
                mean_IoU = IoU_array.mean()
                logging.info('mIoU: %.4f' % (mean_IoU))

    pos = confusion_matrix.sum(1)
    res = confusion_matrix.sum(0)
    tp = np.diag(confusion_matrix)
    pixel_acc = tp.sum()/pos.sum()
    mean_acc = (tp/np.maximum(1.0, pos)).mean()
    IoU_array = (tp / np.maximum(1.0, pos + res - tp))
    mean_IoU = IoU_array.mean()

    return mean_IoU, IoU_array, pixel_acc, mean_acc

def test(config, test_dataset, testloader, model, 
        sv_dir='', sv_pred=True):
    model.eval()
    with torch.no_grad():
        for _, batch in enumerate(tqdm(testloader)):
            image, size, name = batch
            size = size[0]
            pred = test_dataset.multi_scale_inference(
                        model, 
                        image, 
                        scales=config.TEST.SCALE_LIST, 
                        flip=config.TEST.FLIP_TEST)
            
            if pred.size()[-2] != size[0] or pred.size()[-1] != size[1]:
                pred = F.upsample(pred, (size[-2], size[-1]), 
                                   mode='bilinear')

            if sv_pred:
                sv_path ='./test_results'
                #sv_path = os.path.join(sv_dir,'test_results')
                if not os.path.exists(sv_path):
                    os.mkdir(sv_path)
                test_dataset.save_pred(pred.cpu(), sv_path, name)
                #test_dataset.save_pred(pred.cpu(), sv_path, name)